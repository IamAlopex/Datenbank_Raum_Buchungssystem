/* Moodle Media Lab Booking System V4 – JavaScript-Vorlage (gleicher Code in allen drei Aktivitäten)
 * Reines Vanilla-JS, keine externen Bibliotheken.
 * Wichtig zur Rollenverteilung: Alles Gespeicherte wird von MOODLE gespeichert und per Moodle-Rechten geschützt
 * (Formular-Speichern, native Freigabe). Dieses Skript bedient diese Funktionen nur komfortabel, es speichert nichts lokal.
 * Rollen: requests = Buchungsportal + einzige Datenquelle, review = Administrations-Dashboard, display = Raumplan/Monitor.
 */
(function () {
  'use strict';

  var PRESET_KIND = 'display'; /* wird beim Bau je Preset gesetzt: requests | review | display */

  var CFG = {
    /* ZENTRALE SLOT-DEFINITION (wird beim Bau aus derselben Quelle erzeugt wie die Menüoptionen der Felder
     * preferred_start / preferred_end / approved_start / approved_end). special = nur auf Spezialanfrage. */
    slots: [{"n": 1, "start": "08:00", "end": "08:45", "special": false}, {"n": 2, "start": "08:45", "end": "09:30", "special": false}, {"n": 3, "start": "09:50", "end": "10:35", "special": false}, {"n": 4, "start": "10:35", "end": "11:20", "special": false}, {"n": 5, "start": "11:40", "end": "12:25", "special": false}, {"n": 6, "start": "12:25", "end": "13:15", "special": false}, {"n": 7, "start": "13:45", "end": "14:30", "special": true}, {"n": 8, "start": "14:30", "end": "15:15", "special": false}, {"n": 9, "start": "15:15", "end": "16:00", "special": false}],
    weekdays: [1, 2, 3, 4, 5],                       /* Montag bis Freitag; 0 = Sonntag */
    /* Sperrregeln je Wochentag (JS-Wochentag: 3 = Mittwoch, 5 = Freitag). Ein Slot ist gesperrt, wenn er ab `from` beginnt. */
    limits: {
      3: { from: '13:15', note: 'Ab 13:15 Uhr – Keine Buchungen möglich' },
      5: { from: '13:15', until: '15:30', label: 'Social Media AG', note: 'Ab 13:15 Uhr – Keine Buchungen möglich' }
    },
    dayStart: '08:00', dayEnd: '16:00',
    refreshSeconds: 30,
    roomName: 'Media Lab',
    /* Ticketnummer = Moodle-Eintrags-ID (vom Datenbankserver atomar vergeben, nie wiederverwendet), vierstellig formatiert.
     * ticketOffset einmalig auf (ID der ersten echten Buchung − 1) setzen, damit die Zählung bei 0001 beginnt. Siehe README. */
    ticketOffset: 0,
    approvedLabel: 'Genehmigt', pendingLabel: 'Ausstehend', rejectedLabel: 'Abgelehnt',
    altLabel: 'Alternativtermin vorgeschlagen', cancelledLabel: 'Storniert',
    specialLabel: 'Spezialanfrage', regularLabel: 'Regulär',
    monitor: { showPending: true, showRejected: true },
    /* Die Schwester-Aktivitäten werden im Kurs über den Namen gefunden. Klappt das nicht: Kursmodul-IDs (cmid) eintragen. */
    names: { requests: 'booking_requests', review: 'booking_review', display: 'room_display' },
    ids: { requests: 0, review: 0, display: 0 }
  };
  var STATUS = [CFG.pendingLabel, CFG.approvedLabel, CFG.rejectedLabel, CFG.altLabel, CFG.cancelledLabel];

  /* ---------- Helfer ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function ticketNo(id) {
    var raw = parseInt(id, 10), n = raw - (CFG.ticketOffset || 0);
    if (!(n >= 1)) { n = raw; }
    var s = String(n); while (s.length < 4) { s = '0' + s; }
    return s;
  }
  function sesskey() { return (window.M && M.cfg && M.cfg.sesskey) ? String(M.cfg.sesskey) : ''; }
  var SLUG_OF = {}; SLUG_OF[CFG.pendingLabel] = 'pending'; SLUG_OF[CFG.approvedLabel] = 'approved'; SLUG_OF[CFG.rejectedLabel] = 'rejected'; SLUG_OF[CFG.altLabel] = 'alt'; SLUG_OF[CFG.cancelledLabel] = 'cancelled';
  function stBadge(status, slug) { return '<span class="mbs-st" data-s="' + (slug || SLUG_OF[status] || 'pending') + '">' + esc(status) + '</span>'; }
  function isoDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function isoDateTime(d) { return isoDate(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function toMin(t) { var m = /^(\d{1,2}):(\d{2})/.exec(String(t || '').trim()); return m ? (+m[1]) * 60 + (+m[2]) : NaN; }
  function fromMin(n) { return pad(Math.floor(n / 60)) + ':' + pad(n % 60); }
  function normDate(s) {
    s = String(s || '').trim();
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
    if (m) { return m[1] + '-' + pad(+m[2]) + '-' + pad(+m[3]); }
    m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})/.exec(s);
    if (m) { return m[3] + '-' + pad(+m[2]) + '-' + pad(+m[1]); }
    return s;
  }
  function parseDate(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; }
  function wdName(iso) { var d = parseDate(iso); return d ? ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d.getDay()] : ''; }
  function fmtDate(iso) { var d = parseDate(iso); return d ? wdName(iso) + ', ' + pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() : (iso || ''); }
  function overlaps(a1, a2, b1, b2) { return a1 < b2 && b1 < a2; }
  function params() { return new URLSearchParams(location.search); }
  function kind() { if (PRESET_KIND) { return PRESET_KIND; } var n = $('[data-kind]'); return n ? n.getAttribute('data-kind') : ''; }
  function siteRoot() { return location.pathname.replace(/\/mod\/data\/[^\/]*$/, ''); }
  function baseDir() { return location.pathname.replace(/[^\/]*$/, ''); }
  function dbQuery() {
    var p = params();
    if (p.get('d')) { return 'd=' + encodeURIComponent(p.get('d')); }
    if (p.get('id')) { return 'id=' + encodeURIComponent(p.get('id')); }
    return '';
  }
  function viewUrl(extra) { return baseDir() + 'view.php?' + dbQuery() + (extra ? '&' + extra : ''); }
  function addUrl() { return baseDir() + 'edit.php?' + dbQuery(); }
  function viewByCm(cm, extra) { return siteRoot() + '/mod/data/view.php?id=' + encodeURIComponent(cm) + (extra ? '&' + extra : ''); }

  /* Reine Oberflächen-Erkennung (KEINE Sicherheitsfunktion). */
  function isAdmin() {
    return !!$('a[href*="/mod/data/field.php"], a[href*="/mod/data/templates.php"], a[href*="/mod/data/preset.php"], a[href*="/mod/data/presets.php"]');
  }
  function currentUserName() {
    var n = $('.usermenu .usertext') || $('#user-menu-toggle .usertext') || $('.usermenu .userbutton');
    return n ? n.textContent.replace(/\s+/g, ' ').trim() : '';
  }
  function courseId() {
    if (window.M && M.cfg && M.cfg.courseId && +M.cfg.courseId > 1) { return String(M.cfg.courseId); }
    var a = $('a[href*="/course/view.php?id="]'), m = a && /[?&]id=(\d+)/.exec(a.getAttribute('href'));
    return m ? m[1] : '';
  }
  function discover(role) {
    if (CFG.ids[role]) { return Promise.resolve(String(CFG.ids[role])); }
    var key = 'mbs_v3_cm_' + role, cached = '';
    try { cached = sessionStorage.getItem(key) || ''; } catch (e) { /* ignore */ }
    if (cached) { return Promise.resolve(cached); }
    var cid = courseId(); if (!cid) { return Promise.resolve(''); }
    return fetch(siteRoot() + '/course/view.php?id=' + encodeURIComponent(cid), { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.text() : ''; })
      .then(function (t) {
        if (!t) { return ''; }
        var doc = new DOMParser().parseFromString(t, 'text/html'), found = '', want = CFG.names[role].toLowerCase();
        $$('a[href*="/mod/data/view.php?id="]', doc).some(function (a) {
          var inst = $('.instancename', a), txt = ((inst && inst.firstChild ? inst.firstChild.textContent : a.textContent) || '').trim().toLowerCase();
          var m = /[?&]id=(\d+)/.exec(a.getAttribute('href'));
          if (m && txt.indexOf(want) === 0) { found = m[1]; return true; }
          return false;
        });
        if (found) { try { sessionStorage.setItem(key, found); } catch (e) { /* ignore */ } }
        return found;
      }).catch(function () { return ''; });
  }

  /* =====================================================================
   * Slots und Sperrregeln (zentral, siehe CFG)
   * ===================================================================== */
  function slotsIn(start, end) {
    var s = toMin(start), e = toMin(end);
    if (isNaN(s) || isNaN(e)) { return []; }
    return CFG.slots.filter(function (sl) { return toMin(sl.start) >= s && toMin(sl.end) <= e; });
  }
  function slotLabel(list) {
    if (!list.length) { return ''; }
    var a = list[0], b = list[list.length - 1];
    return (a.n === b.n ? 'Slot ' + a.n : 'Slot ' + a.n + '–' + b.n) + ' · ' + a.start + '–' + b.end;
  }
  function timeLabel(start, end) {
    var l = slotsIn(start, end);
    if (l.length) { return slotLabel(l); }
    return (start && end) ? start + '–' + end : 'Zeit nach Absprache';
  }
  /* Ist dieser Slot an diesem Datum grundsätzlich nicht regulär buchbar? → { reason, ag } oder null */
  function slotBlock(iso, sl) {
    var d = parseDate(iso); if (!d) { return { reason: 'Kein gültiges Datum' }; }
    var wd = d.getDay();
    if (CFG.weekdays.indexOf(wd) < 0) { return { reason: 'Am Wochenende nicht buchbar' }; }
    var l = CFG.limits[wd];
    if (l && toMin(sl.start) >= toMin(l.from)) { return { reason: l.label ? l.label + ' (' + l.from + '–' + l.until + ' Uhr)' : l.note, ag: !!l.label }; }
    return null;
  }
  function isSpecialRange(start, end) { return slotsIn(start, end).some(function (s) { return s.special; }); }

  /* =====================================================================
   * Ticket-Modell (aus den Karten der Listen-Vorlage)
   * ===================================================================== */
  /* Freigabe-Erkennung: verlassen kann man sich nur auf das, was Moodle je nach Recht ausgibt.
   *  - Link „disapprove=…“ → freigegeben;  Link „approve=…“ → offen (beide nur für Freigebende sichtbar)
   *  - Sonst liefert Moodle fremde Einträge nur, wenn sie freigegeben sind; eigene offene erkennt man an Bearbeiten-/Löschen-Links
   *    (bei „genehmigte Einträge nicht änderbar“) bzw. am Moodle-Text. Im Zweifel: NICHT freigegeben. */
  function urlsIn(node) {   /* Moodle-Version/Theme-tolerant: Links, data-Attribute, Formular-Aktionen */
    var out = [];
    $$('a[href]', node).forEach(function (a) { out.push(a.getAttribute('href') || ''); });
    $$('[data-url],[data-href],[data-action-url]', node).forEach(function (e) { out.push(e.getAttribute('data-url') || e.getAttribute('data-href') || e.getAttribute('data-action-url') || ''); });
    $$('[formaction]', node).forEach(function (e) { out.push(e.getAttribute('formaction') || ''); });
    $$('form[action]', node).forEach(function (f) {
      var u = f.getAttribute('action') || '', h = $$('input[type=hidden]', f).map(function (i) { return i.name + '=' + i.value; }).join('&');
      out.push(u + (u.indexOf('?') > -1 ? '&' : '?') + h);
    });
    return out;
  }
  function approvalOf(node) {
    var links = {};
    urlsIn(node).forEach(function (h) {
      if (/[?&]disapprove=/.test(h)) { links.disapprove = h; }
      else if (/[?&]approve=/.test(h)) { links.approve = h; }
      else if (/[?&]delete=/.test(h)) { links.del = h; }
      else if (/\/edit\.php/.test(h)) { links.edit = h; }
    });
    var src = $('.mbs-approval-src', node), txt = '';
    if (src) {
      txt = src.textContent + ' ' + $$('[title],[alt],[aria-label]', src).map(function (x) { return (x.getAttribute('title') || '') + ' ' + (x.getAttribute('alt') || '') + ' ' + (x.getAttribute('aria-label') || ''); }).join(' ');
    }
    var pendingTxt = /(^|[^a-zäöüß])(nicht|not|pending|ausstehend|wartet|unapproved|ungenehmigt|notapproved)([^a-zäöüß]|$)/i.test(txt);
    var canEdit = !!(links.edit || links.del), approved, positiveTxt = !pendingTxt && /genehmigt|freigegeben|approved/i.test(txt);
    if (links.disapprove) { approved = true; }
    else if (links.approve || pendingTxt) { approved = false; }
    else if (positiveTxt) { approved = true; }
    else if (canEdit) { approved = false; }
    else { approved = true; }
    return { approved: approved, canEdit: canEdit, links: links };
  }
  function txt(n, sel, keepNl) {
    var e = $(sel, n); if (!e) { return ''; }
    return keepNl ? e.textContent.trim() : e.textContent.replace(/\s+/g, ' ').trim();
  }
  function parseTicket(n) {
    var d = n.dataset, ap = approvalOf(n), act = $('.mbs-src-activities', n), list = [];
    if (act) {
      var c = act.cloneNode(true);
      $$('br', c).forEach(function (b) { b.parentNode.replaceChild(document.createTextNode('|'), b); });
      list = c.textContent.split('|').map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
    }
    return {
      node: n, id: d.id,
      group: (d.group || '').trim(), subject: (d.subject || '').trim(), teacher: (d.teacher || '').trim(), title: (d.title || '').trim(),
      type: (d.type || '').trim(), room: (d.room || '').trim(),
      date: normDate(d.date), start: (d.start || '').trim(), end: (d.end || '').trim(),
      altdate: normDate(d.altdate), alttime: (d.alttime || '').trim(), custom: (d.custom || '').trim() === 'Ja',
      duration: (d.duration || '').trim(), status: (d.status || '').trim() || CFG.pendingLabel,
      adate: normDate(d.adate), astart: (d.astart || '').trim(), aend: (d.aend || '').trim(),
      created: (d.created || '').trim(), approvedBy: (d.approvedby || '').trim(), approvalDate: (d.approvaldate || '').trim(),
      activities: list, desc: txt(n, '.mbs-src-desc', true), reason: txt(n, '.mbs-comment-text', true),
      by: txt(n, '.mbs-by-name'), added: txt(n, '.mbs-added'), modified: txt(n, '.mbs-src-mod'),
      approved: ap.approved, canEdit: ap.canEdit, links: ap.links
    };
  }
  function readTickets(root) { return $$('.mbs-card[data-id]', root).map(parseTicket); }

  function wish(t) { return { date: t.date, start: t.start, end: t.end }; }
  function binding(t) {
    if (t.status === CFG.approvedLabel && t.adate && t.astart && t.aend) { return { date: t.adate, start: t.astart, end: t.aend }; }
    return wish(t);
  }
  function proposalOf(t) { return (t.status === CFG.altLabel && t.adate && t.astart && t.aend) ? { date: t.adate, start: t.astart, end: t.aend } : null; }
  function isConfirmed(t) { return t.approved && t.status === CFG.approvedLabel; }   /* Moodle-Freigabe UND Status */
  function isSpecial(t) { var w = wish(t); return t.type === CFG.specialLabel || isSpecialRange(w.start, w.end); }
  function placeOf(t) { return isConfirmed(t) ? binding(t) : wish(t); }
  function shortActivity(a) { return String(a).replace(/\s*\(.*$/, '').trim(); }
  function conflictsWith(all, place, exceptId) {
    var s = toMin(place.start), e = toMin(place.end);
    return all.filter(function (t) {
      if (String(t.id) === String(exceptId) || !isConfirmed(t)) { return false; }
      var b = binding(t);
      return b.date === place.date && !isNaN(toMin(b.start)) && !isNaN(toMin(b.end)) && overlaps(s, e, toMin(b.start), toMin(b.end));
    });
  }

  /* ---------- Laden (die Tickets liegen ausschließlich in booking_requests) ---------- */
  function fetchDocument(url) {
    return fetch(url, { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok || /\/login\//.test(r.url)) { throw new Error('Nicht angemeldet oder Server nicht erreichbar'); }
      return r.text();
    }).then(function (t) { return new DOMParser().parseFromString(t, 'text/html'); });
  }
  function sourceUrl() {
    var tail = 'mode=list&perpage=1000';
    if (kind() === 'requests') { return Promise.resolve(viewUrl(tail)); }
    return discover('requests').then(function (cm) {
      if (!cm) { throw new Error('Aktivität „' + CFG.names.requests + '“ wurde im Kurs nicht gefunden. Name prüfen oder CFG.ids in der JavaScript-Vorlage setzen.'); }
      return viewByCm(cm, tail);
    });
  }
  function loadRequestCards() {
    return sourceUrl().then(function (url) {
      return fetchDocument(url).then(function (doc) {
        return $$('.mbs-card[data-id]', doc).map(function (card) {
          $$('a[href]', card).forEach(function (a) {
            var href = a.getAttribute('href');
            if (href && !/^(?:[a-z][a-z0-9+.-]*:|#|\/\/)/i.test(href)) { a.setAttribute('href', new URL(href, location.origin + url).href); }
          });
          return card;
        });
      });
    });
  }
  function loadTickets() {
    return loadRequestCards().then(function (nodes) {
      var holder = document.createElement('div');
      nodes.forEach(function (n) { holder.appendChild(document.importNode(n, true)); });
      return readTickets(holder);
    });
  }
  function sourceError(root, message) {
    var box = $('.mbs-toolbar', root);
    if (box) { box.innerHTML = '<div class="mbs-banner mbs-banner-warn"><strong>Verbindung nicht verfügbar.</strong> ' + esc(message) + '</div>'; }
    var empty = $('#mbs-empty', root); if (empty) { empty.hidden = false; empty.textContent = 'Die Quelldatenbank konnte nicht geladen werden.'; }
  }

  /* =====================================================================
   * Gemeinsame, rein lesende Detail-Darstellung einer Buchung (Dashboard, Formular-Aufruf bestehender Buchungen)
   * ===================================================================== */
  function createdText(t) {
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}:\d{2}))?/.exec(t.created || '');
    return m ? m[3] + '.' + m[2] + '.' + m[1] + (m[4] ? ' ' + m[4] : '') : (t.added || '');
  }
  function dlHTML(rows) { return '<dl class="mbs-dl">' + rows.map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>'; }).join('') + '</dl>'; }
  function detailHTML(t, o) {
    o = o || {};
    var w = wish(t), pr = proposalOf(t), fin = (t.status === CFG.approvedLabel && t.adate && t.astart && t.aend) ? fmtDate(t.adate) + ' · ' + timeLabel(t.astart, t.aend) : '';
    var wishTxt = (w.start && w.end) ? fmtDate(w.date) + ' · ' + timeLabel(w.start, w.end) + ' (' + w.start + '–' + w.end + ')' : (w.date ? fmtDate(w.date) + ' · Zeit nach Absprache' : '');
    var decision = [['Status', t.status]];
    if (fin) { decision.push(['Vergebener Termin', fin]); }
    if (pr) { decision.push(['Vorschlag der Media-Lab-Leitung', fmtDate(pr.date) + ' · ' + timeLabel(pr.start, pr.end)]); }
    decision.push(['Entschieden von / am', [t.approvedBy, t.approvalDate].filter(Boolean).join(' · ')]);
    if (o.admin) { decision.push(['Moodle-Freigabe', t.approved ? 'freigegeben' : 'nicht freigegeben']); }
    if (o.admin || o.own) { decision.push([o.admin ? 'Interner Kommentar / Grund' : 'Rückmeldung der Media-Lab-Leitung', t.reason]); }
    return '<div class="mbs-detail"><div class="mbs-detail-head"><span class="mbs-no">Nr. ' + esc(ticketNo(t.id)) + '</span><h2>' + esc(t.group) + '</h2>' + stBadge(t.status) + (isSpecial(t) ? stBadge('Spezialanfrage', 'special') : '') + '</div>' +
      '<section class="mbs-dsec"><h4>Anfrage</h4>' + dlHTML([['Gruppe / Beteiligte', t.group], ['Fach', t.subject], ['Lehrkraft', t.teacher], ['Geplantes Vorhaben', t.activities.join('\n')], ['Idee', t.desc]]) + '</section>' +
      '<section class="mbs-dsec"><h4>Termin</h4>' + dlHTML([['Raum', t.room], ['Art der Anfrage', t.type], ['Benötigte Zeit', t.duration], ['Wunschtermin', wishTxt],
        ['Eigener Terminvorschlag', t.custom ? [t.altdate ? fmtDate(t.altdate) : '', t.alttime].filter(Boolean).join(' · ') || 'Ja' : 'Nein']]) + '</section>' +
      '<section class="mbs-dsec"><h4>Entscheidung</h4>' + dlHTML(decision) + '</section>' +
      '<section class="mbs-dsec"><h4>Eingang</h4>' + dlHTML([['Eingereicht von', t.by], ['Eingereicht am', createdText(t)], ['Zuletzt geändert', t.modified], ['Moodle-Eintrag', t.id]]) + '</section>' +
      '<div class="mbs-readonly">Alle Angaben sind nur lesbar. Die ursprünglichen Formulardaten können nach dem Absenden nicht mehr geändert werden.</div></div>';
  }
  function fillTicketNumbers(root) {
    $$('.mbs-no[data-no]', root).forEach(function (e) { e.textContent = (e.getAttribute('data-prefix') || '') + ticketNo(e.getAttribute('data-no')); });
  }

  /* =====================================================================
   * 1) BUCHUNGSPORTAL – sechs Fragen im Add-Template (nur Anfrage, keine Verwaltung)
   * ===================================================================== */
  function makeForm(root) {
    var F = {};
    F.wrap = function (n) { return $('[data-mbs-field="' + n + '"]', root); };
    F.inp = function (n) { var w = F.wrap(n); return w && w.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),select,textarea'); };
    F.val = function (n) {
      var i = F.inp(n); if (!i) { return ''; }
      if (i.tagName === 'SELECT') { return i.value ? i.options[i.selectedIndex].text.trim() : ''; }
      return (i.value || '').trim();
    };
    F.setVal = function (n, v) {
      var w = F.wrap(n); if (!w) { return; }
      var rs = $$('input[type=radio]', w);
      if (rs.length) {
        rs.forEach(function (r) {
          var l = $('label[for="' + r.id + '"]', root), t = (r.value + ' ' + (l ? l.textContent : '')).trim();
          r.checked = (r.value === v) || t.split(/\s+/).indexOf(v) > -1;
        });
        return;
      }
      var i = F.inp(n); if (!i) { return; }
      if (i.tagName === 'SELECT') {
        i.selectedIndex = 0;
        for (var k = 0; k < i.options.length; k++) { if (v !== '' && (i.options[k].text.trim() === v || i.options[k].value === v)) { i.selectedIndex = k; break; } }
      } else { i.value = v; }
      i.dispatchEvent(new Event('change', { bubbles: true }));
    };
    F.setIfEmpty = function (n, v) { if (!F.val(n) && v !== '' && v != null) { F.setVal(n, String(v)); } };
    F.checks = function (n) { return $$('input[type=checkbox]', F.wrap(n) || root); };
    F.label = function (c) { var l = $('label[for="' + c.id + '"]', root); return l ? l.textContent.trim() : c.value; };
    F.radio = function (n) { var r = $$('input[type=radio]:checked', F.wrap(n) || root)[0]; return r ? r.value : ''; };
    return F;
  }
  function listUrl() { return baseDir() + 'view.php?' + dbQuery(); }

  function initAdd() {
    var root = $('#mbs-add'); if (!root || kind() !== 'requests' || params().get('mbs') === 'raw') { return; }
    var form = root.closest('form') || document;
    function unlock() { $$('input[type=submit], button[type=submit]', form).forEach(function (b) { b.disabled = false; }); }
    try { runForm(root, form); } catch (e) {
      if (window.console) { console.error('[mbs]', e); }
      root.classList.remove('mbs-js'); unlock();   /* Rückfall: normales Moodle-Formular */
    }
  }

  /* Bestehende Buchung im Formular geöffnet: ausschließlich Lese-Ansicht, kein Bearbeiten */
  function showReadOnly(root, form, F) {
    var acts = F.checks('activities').filter(function (c) { return c.checked; }).map(F.label);
    var t = { id: params().get('rid'), group: F.val('user_name'), subject: F.val('subject'), teacher: F.val('teacher'), title: F.val('booking_title'), type: F.val('booking_type'), room: F.val('room'),
      date: normDate(F.val('preferred_date')), start: F.val('preferred_start'), end: F.val('preferred_end'), altdate: normDate(F.val('alternative_date')), alttime: F.val('alternative_time'),
      custom: F.radio('is_custom_request') === 'Ja', duration: F.val('duration'), status: F.val('booking_status') || CFG.pendingLabel, adate: normDate(F.val('approved_date')), astart: F.val('approved_start'), aend: F.val('approved_end'),
      created: F.val('created_at'), approvedBy: F.val('approved_by'), approvalDate: F.val('approval_date'), reason: F.val('admin_comment'), activities: acts, desc: F.val('description'), by: currentUserName(), modified: '', added: '' };
    var box = $('#mbs-readonly', root);
    box.innerHTML = '<a class="mbs-back" href="' + esc(listUrl()) + '">← Zur Übersicht</a>' + detailHTML(t, { own: true }) +
      '<p class="mbs-note">Dieses Formular dient nur dem Anlegen neuer Buchungen. Bestehende Buchungen können nicht geändert werden.</p>';
    box.hidden = false;
    $$('.mbs-notice,.mbs-form,.mbs-auto,.mbs-tech', root).forEach(function (n) { n.hidden = true; });
    $$('input[type=submit], button[type=submit]', form).forEach(function (b) { b.style.display = 'none'; });
    form.addEventListener('submit', function (e) { e.preventDefault(); });
    fillTicketNumbers(root);
  }

  function runForm(root, form) {
    root.classList.add('mbs-js');
    var F = makeForm(root), editing = !!params().get('rid');
    if (editing) { showReadOnly(root, form, F); return; }
    var tech = $('[data-mbs-technical]', root); if (tech && tech.parentNode) { tech.parentNode.removeChild(tech); }   /* Entscheidungsfelder gehören nicht zum Anfrageformular */
    var today = isoDate(new Date()), busy = [], busyKnown = false, sel = null;   /* sel = { date, i, N } */

    /* Datumsfelder: Texteingabe → native Datumsauswahl (liefert ISO) */
    ['preferred_date', 'alternative_date'].forEach(function (n) {
      var i = F.inp(n);
      if (i) { i.type = 'date'; i.value = normDate(i.value); i.min = today; var h = i.parentNode && i.parentNode.querySelector('.mbs-hint'); if (h) { h.hidden = true; } }
    });

    var ta = F.inp('description'); if (ta && ta.tagName === 'TEXTAREA') { ta.rows = 3; }   /* kompakt: 3 Zeilen, vergrößerbar */

    /* Automatisch gesetzte Felder */
    F.setIfEmpty('room', CFG.roomName);
    F.setIfEmpty('created_at', isoDateTime(new Date()));

    /* Frage 3: Auswahlkarten (Mehrfachauswahl) */
    $$('br', F.wrap('activities') || root).forEach(function (b) { b.parentNode.removeChild(b); });
    F.checks('activities').forEach(function (c) {
      var l = $('label[for="' + c.id + '"]', root); if (!l) { return; }
      l.classList.add('mbs-choice');
      function sync() { l.classList.toggle('is-on', c.checked); }
      c.addEventListener('change', function () { sync(); summary(); });
      c.addEventListener('focus', function () { l.classList.add('is-focus'); });
      c.addEventListener('blur', function () { l.classList.remove('is-focus'); });
      sync();
    });

    /* Frage 5: Dauer als Auswahl-Chips (das Menüfeld bleibt die gespeicherte Quelle) */
    var dsel = F.inp('duration'), dbox = null;
    function durN() { var m = /^(\d)\s*Slot/.exec(F.val('duration')); return m ? +m[1] : 0; }
    function syncDur() { if (dbox) { $$('.mbs-chip', dbox).forEach(function (b) { b.classList.toggle('is-on', b.textContent === F.val('duration')); }); } }
    if (dsel) {
      dsel.style.display = 'none';
      dbox = document.createElement('div'); dbox.className = 'mbs-chips';
      for (var k = 0; k < dsel.options.length; k++) {
        if (dsel.options[k].value === '') { continue; }
        (function (txt) {
          var b = document.createElement('button'); b.type = 'button'; b.className = 'mbs-chip'; b.textContent = txt;
          b.addEventListener('click', function () { F.setVal('duration', txt); sel = null; syncDur(); renderWindows(); summary(); });
          dbox.appendChild(b);
        }(dsel.options[k].text.trim()));
      }
      dsel.parentNode.insertBefore(dbox, dsel.nextSibling); syncDur();
    }

    /* Frage 6: Datum → Zeitfenster aus den zentral definierten Slots */
    var wbox = $('#mbs-windows', root), toggle = $('#mbs-custom-toggle', root), cbox = $('#mbs-custom-box', root);
    function customOn() { return toggle.checked; }
    function setCustom(on) {
      toggle.checked = on; cbox.hidden = !on;
      F.setVal('is_custom_request', on ? 'Ja' : 'Nein');
      if (on) { sel = null; } else { F.setVal('alternative_date', ''); F.setVal('alternative_time', ''); }
      renderWindows(); summary();
    }
    toggle.addEventListener('change', function () { setCustom(toggle.checked); });

    function windowInfo(iso, i, N, nowMin) {
      var sls = CFG.slots.slice(i, i + N); if (sls.length < N) { return null; }
      var blocked = '', occupied = false, special = false;
      sls.forEach(function (sl) {
        var b = slotBlock(iso, sl); if (b && !blocked) { blocked = b.reason; }
        if (sl.special) { special = true; }
        if (busy.some(function (t) { var p = binding(t); return p.date === iso && overlaps(toMin(sl.start), toMin(sl.end), toMin(p.start), toMin(p.end)); })) { occupied = true; }
      });
      var start = sls[0].start, end = sls[sls.length - 1].end, past = iso === today && toMin(start) <= nowMin;
      var cls = blocked ? 'blocked' : occupied ? 'busy' : past ? 'past' : special ? 'special' : 'free';
      return { cls: cls, label: slotLabel(sls), note: blocked || (occupied ? 'bereits belegt' : past ? 'schon vorbei' : special ? 'nur auf Spezialanfrage' : 'frei') };
    }
    function dateProblem(iso) {
      var d = parseDate(iso);
      if (!d) { return 'Bitte wählt ein Datum.'; }
      if (iso < today) { return 'Das Datum liegt in der Vergangenheit.'; }
      if (CFG.weekdays.indexOf(d.getDay()) < 0) { return 'Am Wochenende ist das Media Lab nicht buchbar.'; }
      return '';
    }
    function renderWindows() {
      if (!wbox) { return; }
      if (customOn()) { wbox.innerHTML = '<p class="mbs-note">Eigener Wunschtermin: Die Media-Lab-Leitung legt die Slots fest.</p>'; return; }
      var iso = normDate(F.val('preferred_date')), N = durN(), h = '';
      if (!F.val('duration')) { wbox.innerHTML = '<p class="mbs-note">Wählt zuerst bei Frage 5 die benötigte Zeit.</p>'; return; }
      if (!N) { wbox.innerHTML = '<p class="mbs-note">Bei längeren Vorhaben legt die Media-Lab-Leitung die Zeit fest. Wählt trotzdem euer Wunschdatum.</p>'; return; }
      var prob = dateProblem(iso);
      if (prob) { wbox.innerHTML = '<p class="mbs-note">' + esc(prob) + '</p>'; return; }
      var now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes(), any = false, lim = CFG.limits[parseDate(iso).getDay()];
      h += '<div class="mbs-wintitle">Zeitfenster am ' + esc(fmtDate(iso)) + '</div>';
      if (lim) { h += '<p class="mbs-note is-info">' + esc(lim.label ? lim.from + '–' + lim.until + ' Uhr – ' + lim.label + '. ' + lim.note : lim.note) + '</p>'; }
      h += '<div class="mbs-wingrid">';
      for (var i = 0; i + N <= CFG.slots.length; i++) {
        var w = windowInfo(iso, i, N, nowMin); if (!w) { continue; }
        var on = sel && sel.date === iso && sel.i === i && sel.N === N, usable = (w.cls === 'free' || w.cls === 'special');
        if (usable) { any = true; }
        h += '<button type="button" class="mbs-win is-' + w.cls + (on ? ' is-on' : '') + '" data-i="' + i + '"' + (usable ? '' : ' disabled') + '><b>' + esc(w.label) + '</b><span>' + esc(w.note) + '</span></button>';
      }
      h += '</div>';
      if (!any) { h += '<p class="mbs-note">Kein regulär buchbares Zeitfenster dieser Länge an diesem Tag. Wählt ein anderes Datum oder schlagt einen eigenen Termin vor.</p>'; }
      h += '<p class="mbs-note">' + (busyKnown ? 'Als „belegt“ markiert sind bereits genehmigte Buchungen.' : 'Belegungshinweise konnten nicht geladen werden.') + ' Das ist ein Hinweis, keine Zusage.</p>';
      wbox.innerHTML = h;
    }
    if (wbox) {
      wbox.addEventListener('click', function (ev) {
        var b = ev.target.closest('.mbs-win'); if (!b || b.disabled) { return; }
        sel = { date: normDate(F.val('preferred_date')), i: +b.dataset.i, N: durN() }; renderWindows(); summary();
      });
    }
    ['preferred_date', 'alternative_date', 'alternative_time', 'user_name', 'subject', 'teacher', 'description'].forEach(function (n) {
      var i = F.inp(n); if (!i) { return; }
      i.addEventListener('change', function () { if (n === 'preferred_date') { sel = null; renderWindows(); } summary(); });
      i.addEventListener('input', summary);
    });
    loadTickets().then(function (list) { busy = list.filter(isConfirmed); busyKnown = true; renderWindows(); })
      .catch(function () { busyKnown = false; renderWindows(); });

    /* ---------- Zusammenfassung, Prüfung, Absenden ---------- */
    function chosenActivities() { return F.checks('activities').filter(function (c) { return c.checked; }).map(F.label); }
    function currentWindow() {
      if (!sel || customOn()) { return null; }
      var sls = CFG.slots.slice(sel.i, sel.i + sel.N); if (sls.length !== sel.N) { return null; }
      return { date: sel.date, start: sls[0].start, end: sls[sls.length - 1].end, label: slotLabel(sls), special: sls.some(function (s) { return s.special; }) };
    }
    function summary() {
      var box = $('#mbs-sum', root); if (!box) { return; }
      var w = currentWindow(), acts = chosenActivities().map(shortActivity), rows = [];
      rows.push(['Wer', F.val('user_name') || '–'], ['Fach / Lehrkraft', (F.val('subject') || '–') + ' / ' + (F.val('teacher') || '–')], ['Vorhaben', acts.join(', ') || '–'], ['Zeit', F.val('duration') || '–']);
      rows.push(['Wunschtermin', customOn() ? 'Eigener Vorschlag: ' + (F.val('alternative_date') ? fmtDate(normDate(F.val('alternative_date'))) : '–') + (F.val('alternative_time') ? ' (' + F.val('alternative_time') + ')' : '')
        : (w ? fmtDate(w.date) + ' · ' + w.label + (w.special ? ' (Spezialanfrage)' : '') : (F.val('preferred_date') ? fmtDate(normDate(F.val('preferred_date'))) + ' · Zeit noch nicht gewählt' : '–'))]);
      box.innerHTML = '<dl>' + rows.map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>'; }).join('') + '</dl><p class="mbs-note">Mit „Speichern“ sendet ihr eine Anfrage, keine Buchungsbestätigung.</p>';
    }
    function validate() {
      var e = [];
      if (!F.val('user_name')) { e.push('Frage 1: Bitte gebt euren Gruppennamen bzw. die Namen der Beteiligten an.'); }
      if (!F.val('subject')) { e.push('Frage 2: Bitte nennt das Fach.'); }
      if (!F.val('teacher')) { e.push('Frage 2: Bitte nennt die zuständige Lehrkraft.'); }
      if (!chosenActivities().length) { e.push('Frage 3: Bitte wählt mindestens eine Tätigkeit.'); }
      if (!F.val('description')) { e.push('Frage 4: Bitte beschreibt eure Idee in 1–2 Sätzen.'); }
      if (!F.val('duration')) { e.push('Frage 5: Bitte wählt, wie viel Zeit ihr braucht.'); }
      if (customOn()) {
        var p = dateProblem(normDate(F.val('alternative_date'))); if (p) { e.push('Frage 6: Eigener Wunschtermin – ' + p); }
      } else {
        var pd = dateProblem(normDate(F.val('preferred_date')));
        if (pd) { e.push('Frage 6: ' + pd); }
        else if (durN() && !currentWindow()) { e.push('Frage 6: Bitte wählt ein Zeitfenster oder schlagt einen eigenen Termin vor.'); }
      }
      return e;
    }
    function compose() {
      var acts = chosenActivities().map(shortActivity), w = currentWindow();
      F.setVal('room', CFG.roomName);
      F.setVal('booking_title', (F.val('user_name') + ' – ' + (acts.join(', ') || 'Media Lab')).slice(0, 250));
      if (customOn()) { F.setVal('preferred_date', normDate(F.val('alternative_date'))); F.setVal('preferred_start', ''); F.setVal('preferred_end', ''); F.setVal('booking_type', CFG.regularLabel); }
      else if (w) { F.setVal('preferred_date', w.date); F.setVal('preferred_start', w.start); F.setVal('preferred_end', w.end); F.setVal('booking_type', w.special ? CFG.specialLabel : CFG.regularLabel); }
      F.setVal('is_custom_request', customOn() ? 'Ja' : 'Nein');
    }
    var err = $('#mbs-error', root);
    form.addEventListener('submit', function (ev) {
      var e = validate();
      if (e.length) {
        ev.preventDefault();
        err.innerHTML = '<strong>Bitte vervollständigen:</strong><ul>' + e.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>'; err.hidden = false;
        err.scrollIntoView({ block: 'center' }); return;
      }
      err.hidden = true; compose();
      try { sessionStorage.setItem('mbs_submitted', '1'); } catch (x) { /* ignorieren */ }
    });
    renderWindows(); summary();
  }

  /* =====================================================================
   * 2) Listen in booking_requests (nur lesend) und Einzelansicht
   * ===================================================================== */
  function decorateCard(t) {
    var n = t.node, sl = $('.mbs-slotlabel', n);
    if (sl) { sl.textContent = (t.custom && !t.start) ? 'Eigener Terminvorschlag' : timeLabel(t.start, t.end); }
    var st = $('.mbs-st', n); if (st) { st.textContent = t.status; st.setAttribute('data-s', SLUG_OF[t.status] || 'pending'); }
    var ap = $('.mbs-approval', n); if (ap) { ap.textContent = t.approved ? 'Freigegeben' : 'Freigabe ausstehend'; ap.setAttribute('data-approved', t.approved ? '1' : '0'); }
    var pr = proposalOf(t), box = $('.mbs-proposal', n);
    if (pr && box) { box.hidden = false; box.innerHTML = '<b>Vorschlag der Media-Lab-Leitung:</b> ' + esc(fmtDate(pr.date) + ' · ' + timeLabel(pr.start, pr.end)); }
    var cm = $('.mbs-comment', n);
    if (cm && (!$('.mbs-comment-text', cm).textContent.trim() || !t.canEdit)) { cm.classList.add('is-empty'); }   /* Rückmeldung nur für Ersteller/Verwaltung */
  }
  function head(title, buttons) {
    return '<div class="mbs-head"><div style="display:flex;align-items:center;gap:16px"><div class="mbs-brand" role="img" aria-label="Theresianum Mainz Media Lab"></div><div class="mbs-title">' + esc(title) + '</div></div><div class="mbs-topbtns">' + (buttons || '') + '</div></div>';
  }
  function requestsList(root) {
    var tickets = readTickets(root), bar = $('#mbs-toolbar', root), banner = '', admin = isAdmin();
    tickets.forEach(decorateCard); fillTicketNumbers(root);
    try {
      if (sessionStorage.getItem('mbs_submitted')) {
        sessionStorage.removeItem('mbs_submitted');
        banner = '<div class="mbs-banner"><strong>Anfrage gespeichert.</strong> Sie ist noch keine Buchungsbestätigung; die Media-Lab-Leitung entscheidet. Den Stand seht ihr hier.</div>';
      }
    } catch (e) { /* ignorieren */ }
    bar.innerHTML = head(admin ? 'Alle Anfragen' : 'Meine Anfragen', (admin ? '<a class="mbs-btn" id="mbs-to-review" href="#" style="display:none">Zum Booking Review</a>' : '') + '<a class="mbs-btn is-primary" href="' + esc(addUrl()) + '">Media Lab buchen</a>') + banner;
    if (admin) { discover('review').then(function (cm) { var a = $('#mbs-to-review'); if (cm && a) { a.href = viewByCm(cm); a.style.display = ''; } }); }
    var empty = $('#mbs-empty'); if (empty) { empty.hidden = tickets.length > 0; empty.textContent = 'Noch keine Anfragen vorhanden.'; }
  }
  function initSingle() {
    var root = $('.mbs-single'); if (!root || params().get('mbs') === 'raw') { return; }
    var card = $('.mbs-detail', root), t = { start: card.dataset.start, end: card.dataset.end, status: (card.dataset.status || '').trim() || CFG.pendingLabel };
    var ap = approvalOf(card); fillTicketNumbers(root);
    $$('.mbs-slotlabel', root).forEach(function (e) { e.textContent = timeLabel(t.start, t.end); });
    var st = $$('.mbs-st', root); st.forEach(function (e) { e.textContent = t.status; e.setAttribute('data-s', SLUG_OF[t.status] || 'pending'); });
    var a = $('.mbs-approval', root); if (a) { a.textContent = ap.approved ? 'Freigegeben' : 'Freigabe ausstehend'; }
    if (!ap.canEdit && !isAdmin()) { $$('.mbs-private', root).forEach(function (e) { e.hidden = true; }); }   /* Rückmeldung nur für Ersteller/Verwaltung */
    var back = $('.mbs-back', root); if (back) { back.href = listUrl(); }
  }

  /* Raumplan (Aktivität room_display): bestätigte Buchungen ab heute */
  function planView(root) {
    var box = $('#mbs-cards', root), bar = $('#mbs-toolbar', root);
    loadTickets().then(function (all) {
      var today = isoDate(new Date());
      var list = all.filter(function (t) { return isConfirmed(t) && binding(t).date >= today; }).sort(function (a, b) {
        var x = binding(a), y = binding(b); return (x.date + x.start) < (y.date + y.start) ? -1 : 1;
      });
      bar.innerHTML = head('Raumplan', '<a class="mbs-btn is-primary" href="' + esc(viewUrl('mbs=room')) + '" target="_blank" rel="noopener">Raum-Dashboard öffnen</a>') +
        '<p class="mbs-note">Angezeigt werden bestätigte Buchungen (Moodle-Freigabe und Status „Genehmigt“).</p>';
      box.innerHTML = list.map(function (t) {
        var b = binding(t);
        return '<article class="mbs-card" data-status="Genehmigt"><div class="mbs-card-head">' + stBadge('Bestätigt', 'approved') + '</div><h3 class="mbs-card-title">' + esc(t.group) + '</h3><p class="mbs-sub">' + esc(t.subject) + ' · ' + esc(t.teacher) + '</p>' +
          '<ul class="mbs-meta"><li><span>Datum</span><strong>' + esc(fmtDate(b.date)) + '</strong></li><li><span>Zeit</span><strong>' + esc(timeLabel(b.start, b.end)) + '</strong></li></ul></article>';
      }).join('');
      var empty = $('#mbs-empty'); if (empty) { empty.hidden = list.length > 0; empty.textContent = 'Keine bestätigten Buchungen ab heute.'; }
    }).catch(function (e) { sourceError(root, e.message); });
  }

  /* =====================================================================
   * 3) BOOKING REVIEW (Aktivität booking_review)
   *    Live-Ansicht auf booking_requests. Entscheidungen werden über das Moodle-Formular (Status, Termin, Zeitpunkt)
   *    und die native Moodle-Freigabe GESPEICHERT und danach vom Server zurückgelesen. Die ursprünglichen Formularangaben
   *    werden nie geändert; es gibt keine Bearbeiten-Funktion für sie.
   * ===================================================================== */
  var SECTIONS = [['new', 'Neue Anfragen'], ['special', 'Spezialanfragen'], ['approved', 'Genehmigte Buchungen'], ['rejected', 'Abgelehnte Buchungen'], ['other', 'Alternativen und Stornierungen'], ['past', 'Vergangene Buchungen']];

  function ticketDate(t) { return isConfirmed(t) ? binding(t).date : (t.status === CFG.approvedLabel && t.adate ? t.adate : t.date); }
  function sectionOf(t, today) {
    var d = ticketDate(t);
    if (d && d < today) { return 'past'; }
    if (t.status === CFG.approvedLabel) { return t.approved ? 'approved' : 'new'; }   /* Status ohne Moodle-Freigabe bleibt zur Klärung offen */
    if (t.status === CFG.rejectedLabel) { return 'rejected'; }
    if (t.status === CFG.altLabel || t.status === CFG.cancelledLabel) { return 'other'; }
    return isSpecial(t) ? 'special' : 'new';
  }

  /* ----- Moodle-Freigabe: Einrichtung prüfen und Ursachen benennen ----- */
  var setupCache = null;
  function approvalSetup() {   /* liest die Aktivitäts-Einstellung „Einträge müssen genehmigt werden“ (nur mit Verwaltungsrecht lesbar) */
    if (setupCache) { return setupCache; }
    setupCache = discover('requests').then(function (cm) {
      if (!cm) { return { cm: '', approval: null, url: '' }; }
      var url = siteRoot() + '/course/modedit.php?update=' + encodeURIComponent(cm);
      return fetchDocument(url).then(function (doc) {
        var el = $('[name=approval]', doc), v = null;
        if (el) { v = (el.type === 'checkbox') ? (el.checked ? '1' : '0') : el.value; }
        return { cm: cm, approval: v === null ? null : v !== '0', url: url };
      }).catch(function () { return { cm: cm, approval: null, url: url }; });
    });
    return setupCache;
  }
  var HELP = {
    off: 'Die Moodle-Freigabe ist in „booking_requests“ ausgeschaltet. Ohne sie kennt Moodle keine Freigabe und gibt keinen Freigeben-Link aus.\nBitte einschalten: booking_requests → Einstellungen → Bereich „Einträge“ → „Einträge müssen genehmigt werden“ = Ja. Es wurde nichts geändert.',
    cap: 'Ihrem Konto fehlt das Recht mod/data:approve in der Aktivität „booking_requests“ (nicht in booking_review). Es wurde nichts geändert.\nBitte in booking_requests → Rechte der Rolle der Verwaltung „mod/data:approve“ erlauben.',
    unknown: 'Moodle bietet für diese Anfrage keine Freigabe an. Mögliche Ursachen: In „booking_requests“ ist „Einträge müssen genehmigt werden“ ausgeschaltet, oder Ihrem Konto fehlt dort das Recht mod/data:approve. Es wurde nichts geändert.'
  };
  function nativeUrl(t, which, setup) {
    if (t.links[which]) { return t.links[which]; }
    var sk = sesskey();   /* gleicher Moodle-Endpunkt wie der Link der Vorlage; Moodle prüft Sitzungsschlüssel und Recht serverseitig */
    return (setup.cm && sk) ? viewByCm(setup.cm, which + '=' + encodeURIComponent(t.id) + '&sesskey=' + encodeURIComponent(sk)) : '';
  }
  function preflightNative(t, which) {   /* VOR jeder Änderung: ist die Moodle-Freigabe überhaupt verfügbar? */
    return approvalSetup().then(function (s) {
      if (s.approval === false) { throw new Error(HELP.off); }
      var url = nativeUrl(t, which, s);
      if (!url) { throw new Error(s.approval === true ? HELP.cap : HELP.unknown); }
      return url;
    });
  }
  function nativeStep(url, t, which) {
    return fetch(url, { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok || /\/login\//.test(r.url)) { throw new Error('Moodle hat die Freigabe-Aktion abgelehnt (HTTP ' + r.status + ').'); }
      return loadTickets();
    }).then(function (list) {
      var cur = currentOf(list, t.id);
      if (cur && cur.approved === (which === 'approve')) { return; }
      return approvalSetup().then(function (s) { throw new Error(s.approval === false ? HELP.off : s.approval === true ? HELP.cap : HELP.unknown); });
    });
  }

  /* ----- Speichern über das Moodle-Formular, mit Rücklesen und Rücknahme ----- */
  function fieldControl(root, name) {
    var w = $('[data-mbs-field="' + name + '"]', root);
    var i = w && w.querySelector('select,textarea,input:not([type=hidden]):not([type=checkbox]):not([type=radio])');
    if (!i) { throw new Error('Feld „' + name + '“ fehlt im Moodle-Formular. Bitte die Vorlagen prüfen.'); }
    return i;
  }
  function setFormField(root, name, value) {
    var i = fieldControl(root, name);
    if (i.tagName === 'SELECT') {
      var ok = false;
      for (var k = 0; k < i.options.length; k++) { if (value !== '' && (i.options[k].text.trim() === value || i.options[k].value === value)) { i.selectedIndex = k; ok = true; break; } }
      if (!ok && value === '') { i.selectedIndex = 0; ok = true; }
      if (!ok) { throw new Error('Die Option „' + value + '“ fehlt im Feld „' + name + '“.'); }
    } else { i.value = value; }
  }
  function getFormField(root, name) {
    var i = fieldControl(root, name);
    if (i.tagName === 'SELECT') { return i.value ? i.options[i.selectedIndex].text.trim() : ''; }
    return String(i.value || '').replace(/\r\n/g, '\n').trim();
  }
  async function saveFields(t, changes) {   /* liefert die vorherigen Werte (für eine Rücknahme) */
    var editUrl = t.links.edit;
    if (!editUrl) { throw new Error('Kein Moodle-Link zum Speichern für diese Anfrage (fehlende Berechtigung?).'); }
    var doc = await fetchDocument(editUrl), root = $('#mbs-add', doc), form = root && root.closest('form'), before = {}, keys = Object.keys(changes);
    if (!form) { throw new Error('Das Moodle-Formular wurde nicht gefunden.'); }
    keys.forEach(function (k) { before[k] = getFormField(root, k); });
    keys.forEach(function (k) { setFormField(root, k, changes[k]); });
    var fd = new FormData(form); if (!fd.has('saveandview')) { fd.append('saveandview', 'Save'); }
    var action = new URL(form.getAttribute('action') || editUrl, new URL(editUrl, location.href)).href;
    var r = await fetch(action, { method: 'POST', body: fd, credentials: 'same-origin' });
    if (!r.ok || /\/login\//.test(r.url)) { throw new Error('Moodle hat das Speichern abgelehnt (HTTP ' + r.status + ').'); }
    var root2 = $('#mbs-add', await fetchDocument(editUrl));   /* Rücklesen vom Server */
    if (!root2) { throw new Error('Kontrolle nach dem Speichern nicht möglich.'); }
    keys.forEach(function (k) {
      if (getFormField(root2, k) !== String(changes[k]).replace(/\r\n/g, '\n').trim()) { throw new Error('Der Server hat „' + k + '“ nicht übernommen. Es wird nichts als gespeichert gemeldet.'); }
    });
    return before;
  }
  function currentOf(list, id) { return list.filter(function (x) { return String(x.id) === String(id); })[0]; }
  /* Entscheidung ausführen: Vorabprüfung → Formular speichern → native Freigabe → bei Fehler alles zurücknehmen */
  async function applyDecision(id, changes, which, check) {
    var fresh = await loadTickets(), cur = currentOf(fresh, id);
    if (!cur) { throw new Error('Die Anfrage wurde nicht mehr gefunden.'); }
    if (check) { check(fresh, cur); }
    var need = which && ((which === 'approve' && !cur.approved) || (which === 'disapprove' && cur.approved)), url = need ? await preflightNative(cur, which) : '';
    var before = await saveFields(cur, changes);
    if (need) {
      try { await nativeStep(url, cur, which); } catch (err) {
        try { await saveFields(cur, before); } catch (e2) { throw new Error(err.message + '\nACHTUNG: Die Änderung konnte nicht zurückgenommen werden. Bitte Anfrage ' + ticketNo(cur.id) + ' prüfen.'); }
        throw new Error(err.message + '\nDie gespeicherten Änderungen wurden zurückgenommen.');
      }
    }
  }

  /* ----- Termin-Auswahl für Annehmen / Alternativvorschlag ----- */
  function pickerHTML(init) {
    var a = init && init.a, b = init && init.b;
    function opts(sel, key) { return '<option value="">–</option>' + CFG.slots.map(function (s) { return '<option value="' + s.n + '"' + (sel === s.n ? ' selected' : '') + '>Slot ' + s.n + ' · ' + s[key] + (s.special ? ' (Spezial)' : '') + '</option>'; }).join(''); }
    return '<div class="mla-pick"><label>Datum<input type="date" class="mla-pd" value="' + esc(init ? init.date : '') + '"></label>' +
      '<label>Von Slot<select class="mla-ps">' + opts(a, 'start') + '</select></label><label>Bis Slot<select class="mla-pe">' + opts(b, 'end') + '</select></label></div><div class="mla-pcheck" aria-live="polite"></div>';
  }
  function initialPick(t) {
    var w = proposalOf(t) || (t.start && t.end ? wish(t) : null), l = w ? slotsIn(w.start, w.end) : [];
    return { date: w ? w.date : (t.date || ''), a: l.length ? l[0].n : null, b: l.length ? l[l.length - 1].n : null };
  }
  function readPick(dlg) {
    var a = +$('.mla-ps', dlg).value || 0, b = +$('.mla-pe', dlg).value || 0;
    var sa = CFG.slots.filter(function (s) { return s.n === a; })[0], sb = CFG.slots.filter(function (s) { return s.n === b; })[0];
    return { date: normDate($('.mla-pd', dlg).value), a: a, b: b, start: sa ? sa.start : '', end: sb ? sb.end : '' };
  }
  function checkPick(all, t, p) {
    var errs = [], notes = [], today = isoDate(new Date());
    if (!parseDate(p.date)) { errs.push('Bitte ein Datum wählen.'); }
    else if (p.date < today) { errs.push('Das Datum liegt in der Vergangenheit.'); }
    if (!p.start || !p.end) { errs.push('Bitte Start- und Endslot wählen.'); }
    else if (p.b < p.a) { errs.push('Der Endslot liegt vor dem Startslot.'); }
    else if (parseDate(p.date)) {
      var sls = CFG.slots.filter(function (s) { return s.n >= p.a && s.n <= p.b; });
      sls.forEach(function (sl) { var bl = slotBlock(p.date, sl); if (bl) { errs.push('Slot ' + sl.n + ' (' + sl.start + '–' + sl.end + '): ' + bl.reason + '.'); } });
      if (sls.some(function (s) { return s.special; })) { notes.push('Enthält den Spezialslot 13:45–14:30 (nur auf Spezialanfrage).'); }
      conflictsWith(all, { date: p.date, start: p.start, end: p.end }, t.id).forEach(function (x) {
        errs.push('Überschneidung mit der genehmigten Buchung „' + x.group + '“ (' + fmtDate(binding(x).date) + ', ' + timeLabel(binding(x).start, binding(x).end) + ').');
      });
    }
    return { errs: errs, notes: notes };
  }

  /* ----- Dialog ----- */
  function openDialog(o) {
    var wrap = document.createElement('div');
    wrap.className = 'mla-modal mbs'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true'); wrap.setAttribute('aria-label', o.title);
    wrap.innerHTML = '<div class="mla-md' + (o.wide ? ' is-wide' : '') + '">' + (o.wide ? '' : '<h3>' + esc(o.title) + '</h3>') + '<div class="mla-mb">' + o.body + '</div><div class="mla-me" role="alert" hidden></div>' +
      '<div class="mla-mf" style="' + (o.wide ? 'padding:0 16px 16px' : '') + '"><button type="button" class="mbs-btn" data-x="cancel">' + (o.confirm ? 'Abbrechen' : 'Schließen') + '</button>' + (o.confirm ? '<button type="button" class="mbs-btn ' + o.tone + '" data-x="ok">' + esc(o.confirm) + '</button>' : '') + '</div></div>';
    document.body.appendChild(wrap);
    var ok = $('[data-x=ok]', wrap), cancel = $('[data-x=cancel]', wrap), er = $('.mla-me', wrap), busy = false;
    function close() { document.removeEventListener('keydown', onKey); if (wrap.parentNode) { wrap.parentNode.removeChild(wrap); } }
    function onKey(e) { if (e.key === 'Escape' && !busy) { close(); } }
    document.addEventListener('keydown', onKey);
    cancel.addEventListener('click', function () { if (!busy) { close(); } });
    wrap.addEventListener('click', function (e) { if (e.target === wrap && !busy) { close(); } });
    if (ok) {
      ok.addEventListener('click', function () {
        if (busy) { return; }
        busy = true; ok.disabled = true; cancel.disabled = true; er.hidden = true; ok.dataset.label = ok.textContent; ok.textContent = 'Speichere …';
        Promise.resolve().then(function () { return o.onConfirm(wrap); }).then(function () { close(); }, function (e) {
          busy = false; ok.disabled = false; cancel.disabled = false; ok.textContent = ok.dataset.label; er.hidden = false; er.textContent = e.message || String(e);
        });
      });
    }
    if (o.onOpen) { o.onOpen(wrap, ok); }
    setTimeout(function () { var f = $('input,select,textarea,button[data-x]', wrap); if (f) { f.focus(); } }, 0);
    return wrap;
  }

  function adminDashboard(root) {
    var bar = $('#mbs-toolbar', root), box = $('#mbs-cards', root);
    if (!isAdmin()) {   /* Rechte erzwingt Moodle; die Oberfläche bietet Entscheidungen nur Konten mit Verwaltungsrechten an */
      bar.innerHTML = head('Booking Review') + '<div class="mbs-banner is-warn"><strong>Dieser Bereich ist für die Media-Lab-Verwaltung.</strong><p>Ihr Konto hat keine Verwaltungsrechte für die Buchungen. Ihre eigenen Anfragen finden Sie in „booking_requests“.</p></div>';
      return;
    }
    var st = { tickets: [], tab: 'new', q: '', date: '', setup: null };
    bar.innerHTML = head('Booking Review', '<button type="button" class="mbs-btn" id="mla-reload">Aktualisieren</button><a class="mbs-btn" id="mla-monitor" href="#" target="_blank" rel="noopener" style="display:none">Raum-Dashboard öffnen</a>') +
      '<div id="mla-setup"></div><div class="mla-toast" id="mla-toast" role="status" hidden></div><div class="mla-tabs" id="mla-tabs" role="tablist"></div>' +
      '<div class="mbs-filters"><input type="search" id="mla-q" placeholder="Gruppe, Fach oder Lehrkraft suchen"><input type="date" id="mla-date" aria-label="Datum"><button type="button" class="mbs-btn" id="mla-reset">Zurücksetzen</button></div>';
    discover('display').then(function (cm) { var a = $('#mla-monitor'); if (cm && a) { a.href = viewByCm(cm, 'mbs=room'); a.style.display = ''; } });
    box.classList.add('mla-list');

    function toast(msg, bad) { var t = $('#mla-toast'); t.textContent = msg; t.className = 'mla-toast' + (bad ? ' is-bad' : ''); t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(function () { t.hidden = true; }, 7000); }
    function setupBanner(tickets) {
      return approvalSetup().then(function (s) {
        var noLinks = tickets.length > 0 && tickets.every(function (t) { return t.canEdit && !t.links.approve && !t.links.disapprove; }), k = null;
        if (s.approval === false) { k = 'off'; } else if (noLinks) { k = s.approval === true ? 'cap' : 'unknown'; }
        st.setup = k ? { kind: k } : null;
        var el = $('#mla-setup'); if (!el) { return; }
        if (!k) { el.innerHTML = ''; return; }
        el.innerHTML = '<div class="mbs-banner is-bad"><strong>' + (k === 'off' ? 'Annehmen ist nicht möglich: Die Moodle-Freigabe ist ausgeschaltet.' : k === 'cap' ? 'Annehmen ist nicht möglich: Das Recht mod/data:approve fehlt.' : 'Moodle bietet keine Freigabe an.') + '</strong><p>' + esc(HELP[k]).replace(/\n/g, '<br>') + '</p>' +
          (s.url ? '<p><a href="' + esc(s.url) + '" target="_blank" rel="noopener">Einstellungen von booking_requests öffnen</a></p>' : '') + '</div>';
        render();
      });
    }
    function reload() {
      return loadTickets().then(function (l) { st.tickets = l; render(); return setupBanner(l); }).catch(function (e) { sourceError(root, e.message); });
    }
    function visible(t) {
      var q = st.q.toLowerCase(), d = st.date, hay = (t.group + ' ' + t.subject + ' ' + t.teacher + ' ' + t.title).toLowerCase();
      return (!q || hay.indexOf(q) > -1) && (!d || ticketDate(t) === d || t.date === d);
    }
    function sortFor(sec, a, b) {
      if (sec === 'approved') { var x = binding(a), y = binding(b); return (x.date + x.start) < (y.date + y.start) ? -1 : 1; }
      if (sec === 'past') { return ticketDate(a) < ticketDate(b) ? 1 : -1; }
      return (+b.id) - (+a.id);
    }
    function flagsHTML(t, all) {
      var f = [], w = wish(t);
      if (isSpecial(t)) { f.push('<li class="is-special">Spezialanfrage: Slot 7 (13:45–14:30) ist nur auf Anfrage buchbar.</li>'); }
      if (t.start && t.end && t.status !== CFG.approvedLabel) {
        slotsIn(w.start, w.end).forEach(function (sl) { var b = slotBlock(w.date, sl); if (b && !f.some(function (x) { return x.indexOf(b.reason) > -1; })) { f.push('<li>Wunschzeit nicht regulär buchbar: ' + esc(b.reason) + '</li>'); } });
        conflictsWith(all, w, t.id).forEach(function (x) { f.push('<li>Überschneidung mit der genehmigten Buchung „' + esc(x.group) + '“.</li>'); });
      }
      if (t.status === CFG.approvedLabel && !t.approved) { f.push('<li>Status „Genehmigt“, aber die Moodle-Freigabe fehlt. Die Buchung gilt nicht als bestätigt.</li>'); }
      if (t.approved && t.status !== CFG.approvedLabel && t.status !== CFG.cancelledLabel) { f.push('<li>In Moodle freigegeben, aber Status „' + esc(t.status) + '“.</li>'); }
      return f.length ? '<ul class="mla-flags">' + f.join('') + '</ul>' : '';
    }
    function itemHTML(t, sec, all) {
      var slug = SLUG_OF[t.status] || 'pending', w = wish(t), h = '<article class="mla-item s-' + slug + (isSpecial(t) ? ' is-special' : '') + '" data-id="' + esc(t.id) + '">';
      h += '<div class="mla-top"><span class="mbs-no">' + esc(ticketNo(t.id)) + '</span><h3>' + esc(t.group) + '</h3>' + stBadge(t.status) + (isSpecial(t) ? stBadge('Spezialanfrage', 'special') : '') + '</div>';
      h += '<p class="mla-sub">' + esc(t.subject) + ' · ' + esc(t.teacher) + (t.activities.length ? ' · ' + esc(t.activities.map(shortActivity).join(', ')) : '') + '</p><p class="mla-desc">' + esc(t.desc) + '</p>';
      var when = (w.start && w.end) ? fmtDate(w.date) + ' · ' + timeLabel(w.start, w.end) : (t.custom ? 'Eigener Vorschlag' + (w.date ? ': ' + fmtDate(w.date) : '') + (t.alttime ? ' (' + t.alttime + ')' : '') : (w.date ? fmtDate(w.date) + ' · Zeit nach Absprache' : '–'));
      h += '<dl class="mla-facts"><div><dt>Wunschtermin</dt><dd>' + esc(when) + '</dd></div><div><dt>Benötigte Zeit</dt><dd>' + esc(t.duration || '–') + '</dd></div><div><dt>Angefragt am</dt><dd>' + esc(createdText(t) || '–') + '</dd></div>';
      if (t.status === CFG.approvedLabel && t.adate) { h += '<div><dt>Vergebener Termin</dt><dd>' + esc(fmtDate(binding(t).date) + ' · ' + timeLabel(binding(t).start, binding(t).end)) + '</dd></div>'; }
      var pr = proposalOf(t); if (pr) { h += '<div><dt>Vorschlag</dt><dd>' + esc(fmtDate(pr.date) + ' · ' + timeLabel(pr.start, pr.end)) + '</dd></div>'; }
      if (t.approvalDate) { h += '<div><dt>Entschieden</dt><dd>' + esc(t.approvalDate + (t.approvedBy ? ' · ' + t.approvedBy : '')) + '</dd></div>'; }
      h += '</dl>' + (t.reason ? '<p class="mla-reason"><b>Interner Kommentar / Grund:</b> ' + esc(t.reason) + '</p>' : '') + flagsHTML(t, all) + '<div class="mla-actions">';
      var open = (sec === 'new' || sec === 'special' || (sec === 'other' && t.status === CFG.altLabel)), blocked = st.setup && st.setup.kind === 'off';
      if (open) {
        h += '<button type="button" class="mbs-btn is-ok" data-act="accept" data-id="' + esc(t.id) + '"' + (blocked ? ' disabled title="Zuerst die Moodle-Freigabe einschalten (siehe Hinweis oben)"' : '') + '>Annehmen</button>' +
          '<button type="button" class="mbs-btn is-danger" data-act="reject" data-id="' + esc(t.id) + '">Ablehnen</button>' +
          (t.status !== CFG.altLabel ? '<button type="button" class="mbs-btn" data-act="alt" data-id="' + esc(t.id) + '">Alternativtermin vorschlagen</button>' : '');
      } else if (sec === 'approved') { h += '<button type="button" class="mbs-btn" data-act="cancel" data-id="' + esc(t.id) + '">Stornieren</button>'; }
      return h + '<button type="button" class="mbs-btn push" data-act="details" data-id="' + esc(t.id) + '">Details</button></div></article>';
    }
    function render() {
      var today = isoDate(new Date()), all = st.tickets, groups = {};
      SECTIONS.forEach(function (s) { groups[s[0]] = []; });
      all.forEach(function (t) { groups[sectionOf(t, today)].push(t); });
      $('#mla-tabs').innerHTML = SECTIONS.map(function (s) {
        var n = groups[s[0]].length;
        return '<button type="button" role="tab" class="mla-tab' + (st.tab === s[0] ? ' is-on' : '') + ((s[0] === 'new' || s[0] === 'special') && n ? ' is-urgent' : '') + '" data-tab="' + s[0] + '">' + esc(s[1]) + '<b>' + n + '</b></button>';
      }).join('');
      var list = groups[st.tab].filter(visible).sort(function (a, b) { return sortFor(st.tab, a, b); });
      box.innerHTML = list.map(function (t) { return itemHTML(t, st.tab, all); }).join('');
      var empty = $('#mbs-empty'); if (empty) { empty.hidden = list.length > 0; empty.textContent = 'In diesem Bereich gibt es keine Einträge.'; }
    }

    /* ----- Entscheidungen ----- */
    function afterSave(msg) { return reload().then(function () { toast(msg); }); }
    function who() { return currentUserName() || 'Verwaltung'; }
    function openDecision(t, act) {
      if (act === 'details') { openDialog({ title: 'Buchungsdetails', wide: true, body: detailHTML(t, { admin: true }) }); return; }
      if (act === 'reject') {
        openDialog({ title: 'Anfrage ablehnen?', tone: 'is-danger', confirm: 'Ja, ablehnen',
          body: '<p>Die Anfrage von <b>' + esc(t.group) + '</b> (' + esc(t.subject) + ') wird abgelehnt. Sie bleibt dauerhaft gespeichert und erscheint im Raum-Dashboard als abgelehnt (ohne Grund).</p><label class="mla-l">Ablehnungsgrund (optional, intern)<textarea class="mla-reason-in" rows="3"></textarea></label>',
          onConfirm: function (dlg) {
            return applyDecision(t.id, { booking_status: CFG.rejectedLabel, admin_comment: $('.mla-reason-in', dlg).value.trim(), approved_by: who(), approval_date: isoDateTime(new Date()) }, 'disapprove')
              .then(function () { return afterSave('Abgelehnt und gespeichert: ' + t.group); });
          } });
        return;
      }
      if (act === 'cancel') {
        openDialog({ title: 'Buchung stornieren?', tone: 'is-danger', confirm: 'Ja, stornieren',
          body: '<p>Die bestätigte Buchung von <b>' + esc(t.group) + '</b> wird storniert und verschwindet aus dem Raum-Dashboard. Der Eintrag bleibt gespeichert.</p><label class="mla-l">Grund (optional, intern)<textarea class="mla-reason-in" rows="2"></textarea></label>',
          onConfirm: function (dlg) {
            var ch = { booking_status: CFG.cancelledLabel, approved_by: who(), approval_date: isoDateTime(new Date()) }, r = $('.mla-reason-in', dlg).value.trim(); if (r) { ch.admin_comment = r; }
            return applyDecision(t.id, ch, 'disapprove').then(function () { return afterSave('Storniert und gespeichert: ' + t.group); });
          } });
        return;
      }
      var isAccept = act === 'accept';   /* accept | alt: Termin wählen, vor dem Speichern gegen frisch geladene Serverdaten prüfen */
      openDialog({ title: isAccept ? 'Anfrage annehmen' : 'Alternativtermin vorschlagen', tone: isAccept ? 'is-ok' : 'is-primary', confirm: isAccept ? 'Verbindlich annehmen' : 'Vorschlag speichern',
        body: '<p><b>' + esc(t.group) + '</b> · ' + esc(t.subject) + ' / ' + esc(t.teacher) + '</p><p class="mbs-note">' + (isAccept ? 'Dieser Termin wird verbindlich gespeichert und im Raum-Dashboard angezeigt.' : 'Der Vorschlag ist nicht verbindlich; die Anfrage erhält den Status „Alternativtermin vorgeschlagen“.') + '</p>' +
          pickerHTML(initialPick(t)) + (isAccept ? '' : '<label class="mla-l">Nachricht an die Gruppe (optional)<textarea class="mla-reason-in" rows="2"></textarea></label>'),
        onOpen: function (dlg, okBtn) {
          function chk() {
            var c = checkPick(st.tickets, t, readPick(dlg)), out = $('.mla-pcheck', dlg);
            out.innerHTML = c.errs.map(function (m) { return '<p class="is-bad">' + esc(m) + '</p>'; }).join('') + c.notes.map(function (m) { return '<p class="is-note">' + esc(m) + '</p>'; }).join('') + (!c.errs.length ? '<p class="is-good">Termin ist frei und regulär buchbar.</p>' : '');
            okBtn.disabled = c.errs.length > 0;
          }
          $$('.mla-pick input,.mla-pick select', dlg).forEach(function (x) { x.addEventListener('input', chk); x.addEventListener('change', chk); }); chk();
        },
        onConfirm: function (dlg) {
          var p = readPick(dlg), note = $('.mla-reason-in', dlg) ? $('.mla-reason-in', dlg).value.trim() : '';
          var ch = { approved_by: who(), approval_date: isoDateTime(new Date()), approved_date: p.date, approved_start: p.start, approved_end: p.end, booking_status: isAccept ? CFG.approvedLabel : CFG.altLabel };
          if (!isAccept && note) { ch.admin_comment = note; }
          return applyDecision(t.id, ch, isAccept ? 'approve' : 'disapprove', function (fresh, cur) {   /* Prüfung gegen frische Serverdaten direkt vor dem Speichern */
            var c = checkPick(fresh, cur, p); if (c.errs.length) { throw new Error(c.errs.join('\n')); }
          }).then(function () { return afterSave((isAccept ? 'Angenommen und gespeichert: ' : 'Alternativvorschlag gespeichert: ') + t.group); });
        } });
    }

    box.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b || b.disabled) { return; }
      var t = currentOf(st.tickets, b.dataset.id); if (t) { openDecision(t, b.dataset.act); }
    });
    $('#mla-tabs').addEventListener('click', function (e) { var b = e.target.closest('[data-tab]'); if (b) { st.tab = b.dataset.tab; render(); } });
    $('#mla-q').addEventListener('input', function () { st.q = this.value; render(); });
    $('#mla-date').addEventListener('change', function () { st.date = this.value; render(); });
    $('#mla-reset').addEventListener('click', function () { st.q = ''; st.date = ''; $('#mla-q').value = ''; $('#mla-date').value = ''; render(); });
    $('#mla-reload').addEventListener('click', function () { reload().then(function () { toast('Aktualisiert.'); }); });
    reload();
    setInterval(function () { if (!$('.mla-modal')) { reload(); } }, 60000);
  }

  /* =====================================================================
   * 4) RAUM-DASHBOARD: …/mod/data/view.php?id=CMID&mbs=room[&view=day|week|month]
   *    Zeigt nur notwendige Angaben: Gruppe, Fach/Lehrkraft, Tätigkeit, Zeit, Status.
   *    Nie: E-Mail, interne Kommentare, Ablehnungsgründe.
   * ===================================================================== */
  var MLR_HTML =
    '<header class="mlr-top"><div class="mlr-brand" role="img" aria-label="Theresianum Mainz Media Lab"></div>' +
    '<div class="mlr-seg" role="tablist" aria-label="Ansicht"><button type="button" data-v="day">Tag</button><button type="button" data-v="week">Woche</button><button type="button" data-v="month">Monat</button></div>' +
    '<div class="mlr-tools"><span class="mlr-conn" id="mlr-conn">Verbinde …</span><span class="mlr-conn" id="mlr-tmini"></span><span class="mlr-mini" id="mlr-mini"></span>' +
    '<button type="button" id="mlr-dark">Dunkel</button><button type="button" id="mlr-fs">Vollbild</button></div></header>' +
    '<div class="mlr-body" id="mlr-body"></div>' +
    '<div class="mlr-alarm" id="mlr-alarm" hidden><div><b>Zeit abgelaufen</b><span>Zum Beenden tippen</span></div></div>';
  var MLR_SIDE =
    '<div class="mlr-clockbox"><div class="mlr-time" id="mlr-time"></div><div class="mlr-wd" id="mlr-wd"></div><div class="mlr-date" id="mlr-date"></div>' +
    '<div class="mlr-prog"><div class="mlr-prog-bar"><i id="mlr-pf" style="width:0"></i></div><span id="mlr-pt"></span></div></div>' +
    '<div class="mlr-timer" id="mlr-timer"><div class="mlr-h">Timer</div><div class="mlr-tval" id="mlr-tval">05:00</div>' +
    '<div class="mlr-tset" id="mlr-tset"><label>Min<input type="number" id="mlr-tmin" min="0" max="99" value="5"></label><label>Sek<input type="number" id="mlr-tsec" min="0" max="59" value="0"></label>' +
    '<div class="mlr-presets"><button type="button" data-m="1">1</button><button type="button" data-m="5">5</button><button type="button" data-m="10">10</button><button type="button" data-m="15">15</button><button type="button" data-m="20">20</button></div></div>' +
    '<div class="mlr-btns"><button type="button" id="mlr-tgo" class="go">Start</button><button type="button" id="mlr-treset">Zurücksetzen</button></div></div>';
  var MLR_LEGEND = '<div class="mlr-legend"><span class="k-ok">Genehmigt</span><span class="k-no">Abgelehnt</span><span class="k-pending">Ausstehend (nicht bestätigt)</span><span class="k-special">Spezialanfrage</span><span class="k-blocked">Gesperrt</span></div>';
  var TAG = { ok: 'Genehmigt', no: 'Abgelehnt', pending: 'Ausstehend · nicht bestätigt', special: 'Spezialanfrage · nicht bestätigt' };
  var MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  var WDLONG = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];

  function addDays(iso, n) { var d = parseDate(iso); d.setDate(d.getDate() + n); return isoDate(d); }
  function mondayOf(iso) { var d = parseDate(iso), k = (d.getDay() + 6) % 7; d.setDate(d.getDate() - k); return isoDate(d); }
  function isoWeek(iso) { var d = parseDate(iso); d.setDate(d.getDate() + 3 - ((d.getDay() + 6) % 7)); var w1 = new Date(d.getFullYear(), 0, 4); return 1 + Math.round(((d - w1) / 86400000 - 3 + ((w1.getDay() + 6) % 7)) / 7); }
  function monKind(t) {
    if (isConfirmed(t)) { return 'ok'; }
    if (t.status === CFG.rejectedLabel) { return CFG.monitor.showRejected ? 'no' : null; }
    if (t.status === CFG.pendingLabel || (t.status === CFG.approvedLabel && !t.approved)) { return CFG.monitor.showPending ? (isSpecial(t) ? 'special' : 'pending') : null; }
    return null;   /* Alternativvorschläge und Stornierungen werden nicht angezeigt */
  }

  function monitor(root) {
    var q = params(), wrap = document.createElement('div'), tickets = [], offline = false, lastOk = null;
    var view = ['day', 'week', 'month'].indexOf(q.get('view')) > -1 ? q.get('view') : 'day', anchor = isoDate(new Date()), built = '';
    document.body.classList.add('mbs-room-mode');
    wrap.className = 'mlr mbs'; wrap.innerHTML = MLR_HTML; document.body.appendChild(wrap);
    function $m(s) { return wrap.querySelector(s); }
    var TKEY = 'mbs_timer_v4', DKEY = 'mbs_dark_v4', body = $m('#mlr-body');

    /* ---------- Hell/Dunkel, Vollbild, Ansicht ---------- */
    var dark = false; try { dark = localStorage.getItem(DKEY) === '1'; } catch (e) { /* ignore */ }
    if (q.get('dark') === '1') { dark = true; }
    function applyDark() { wrap.classList.toggle('is-dark', dark); $m('#mlr-dark').textContent = dark ? 'Hell' : 'Dunkel'; }
    $m('#mlr-dark').addEventListener('click', function () { dark = !dark; try { localStorage.setItem(DKEY, dark ? '1' : '0'); } catch (e) { /* ignore */ } applyDark(); });
    applyDark();
    $m('#mlr-fs').addEventListener('click', function () { if (document.fullscreenElement) { document.exitFullscreen(); } else if (document.documentElement.requestFullscreen) { document.documentElement.requestFullscreen(); } });
    $$('.mlr-seg button', wrap).forEach(function (b) { b.addEventListener('click', function () { setView(b.dataset.v); }); });
    function setView(v, date) { view = v; if (date) { anchor = date; } render(true); }

    /* ---------- Daten pro Tag ---------- */
    function itemsFor(iso) {
      var out = [];
      tickets.forEach(function (t) {
        var k = monKind(t); if (!k) { return; }
        var pl = placeOf(t); if (pl.date !== iso) { return; }
        var sl = slotsIn(pl.start, pl.end); if (!sl.length) { return; }
        out.push({ t: t, kind: k, a: sl[0].n, b: sl[sl.length - 1].n, start: pl.start, end: pl.end });
      });
      return out.sort(function (x, y) { return x.a - y.a || x.b - y.b; });
    }

    /* ---------- Raster (Tag und Woche): Zeilen = Slots ---------- */
    function colHTML(iso, c, compact) {
      var items = itemsFor(iso), lanes = [], h = '', now = new Date(), today = isoDate(now), nm = now.getHours() * 60 + now.getMinutes();
      items.forEach(function (it) { var l = 0; while (lanes[l] !== undefined && lanes[l] >= it.a) { l++; } lanes[l] = it.b; it.lane = l; });
      var L = Math.max(1, lanes.length), inner = '';
      var i = 0, wd = parseDate(iso).getDay();
      while (i < CFG.slots.length) {
        var b0 = slotBlock(iso, CFG.slots[i]); if (!b0) { i++; continue; }
        var j = i; while (j + 1 < CFG.slots.length && slotBlock(iso, CFG.slots[j + 1]) && slotBlock(iso, CFG.slots[j + 1]).reason === b0.reason) { j++; }
        var lim = CFG.limits[wd], main = lim ? (lim.label ? lim.from + '–' + lim.until + ' Uhr – ' + lim.label : lim.note) : b0.reason, sub = (lim && lim.label) ? lim.note : '';
        inner += '<div class="mlr-it k-blocked' + (compact ? ' is-compact' : '') + '" style="grid-row:' + CFG.slots[i].n + '/' + (CFG.slots[j].n + 1) + ';grid-column:1/-1"><b>' + esc(main) + '</b>' + (sub && !compact ? '<span>' + esc(sub) + '</span>' : '') + '</div>';
        i = j + 1;
      }
      items.forEach(function (it) {
        var t = it.t;
        inner += '<div class="mlr-it k-' + it.kind + (compact ? ' is-compact' : '') + '" style="grid-row:' + it.a + '/' + (it.b + 1) + ';grid-column:' + (it.lane + 1) + '" title="' + esc((t.group || t.title) + ' · ' + it.start + '–' + it.end) + '"><em>' + esc(TAG[it.kind]) + '</em><b>' + esc(t.group || t.title) + '</b>' +
          (compact ? '' : '<span>' + esc([t.subject, t.teacher].filter(Boolean).join(' · ')) + '</span>' + (t.activities.length ? '<span>' + esc(t.activities.map(shortActivity).join(' · ')) + '</span>' : '')) + '<span>' + esc(it.start + '–' + it.end) + '</span></div>';
      });
      CFG.slots.forEach(function (sl) {
        var cls = (iso === today && toMin(sl.start) <= nm && nm < toMin(sl.end)) ? ' is-now' : (iso < today || (iso === today && toMin(sl.end) <= nm)) ? ' is-past' : '';
        h += '<div class="mlr-cell' + cls + '" data-d="' + iso + '" data-n="' + sl.n + '" style="grid-column:' + c + ';grid-row:' + (sl.n + 1) + '"></div>';
      });
      return h + '<div class="mlr-col" style="grid-column:' + c + ';grid-row:2/span 9;display:grid;grid-template-rows:repeat(9,minmax(0,1fr));grid-template-columns:repeat(' + L + ',minmax(0,1fr))">' + inner + '</div>';
    }
    function gridHTML(dates, compact, headFn) {
      var h = '<div class="mlr-grid" style="grid-template-columns:8.5em repeat(' + dates.length + ',minmax(0,1fr))"><div class="mlr-gh" style="grid-column:1;grid-row:1;border-left:0">Slot</div>';
      CFG.slots.forEach(function (sl) { h += '<div class="mlr-sl" data-n="' + sl.n + '" style="grid-column:1;grid-row:' + (sl.n + 1) + '"><b>' + sl.n + '</b><span>' + sl.start + '–' + sl.end + '</span>' + (sl.special ? '<em>Spezial</em>' : '') + '</div>'; });
      dates.forEach(function (iso, k) { h += headFn(iso, k + 2) + colHTML(iso, k + 2, compact); });
      return h + '</div>';
    }
    function navHTML(title) { return '<div class="mlr-nav"><button type="button" data-nav="-1" aria-label="Zurück">‹</button><h2>' + esc(title) + '</h2><button type="button" data-nav="1" aria-label="Weiter">›</button><button type="button" data-nav="0">Heute</button></div>'; }

    /* ---------- Ansichten ---------- */
    function renderDay() {
      var d = parseDate(anchor), title = WDLONG[d.getDay()] + ', ' + d.getDate() + '. ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
      if (built !== 'day') { body.innerHTML = '<div class="mlr-day"><div class="mlr-side">' + MLR_SIDE + '</div><div class="mlr-main" id="mlr-main"></div></div>'; built = 'day'; bindTimer(); tick(true); }
      $m('#mlr-main').innerHTML = navHTML(title) + '<div class="mlr-status" id="mlr-status" aria-live="polite"></div>' + gridHTML([anchor], false, function (iso, c) { return '<div class="mlr-gh' + (iso === isoDate(new Date()) ? ' is-today' : '') + '" style="grid-column:' + c + ';grid-row:1">' + esc(wdName(iso) + ', ' + fmtDate(iso).replace(/^[A-Za-z]+, /, '')) + '</div>'; }) + MLR_LEGEND;
      renderStatus(new Date());
    }
    function renderWeek() {
      var mon = mondayOf(anchor), dates = [0, 1, 2, 3, 4].map(function (n) { return addDays(mon, n); }), a = parseDate(dates[0]), b = parseDate(dates[4]);
      var title = 'KW ' + isoWeek(mon) + ' · ' + a.getDate() + '.' + (a.getMonth() === b.getMonth() ? '' : (a.getMonth() + 1) + '.') + '–' + b.getDate() + '. ' + MONTHS[b.getMonth()] + ' ' + b.getFullYear();
      body.innerHTML = navHTML(title) + gridHTML(dates, true, function (iso, c) {
        var d = parseDate(iso); return '<div class="mlr-gh' + (iso === isoDate(new Date()) ? ' is-today' : '') + '" style="grid-column:' + c + ';grid-row:1"><button type="button" data-day="' + iso + '">' + wdName(iso) + '</button><small>' + d.getDate() + '.' + (d.getMonth() + 1) + '.</small></div>';
      }) + MLR_LEGEND; built = 'week';
    }
    function renderMonth() {
      var d = parseDate(anchor), first = isoDate(new Date(d.getFullYear(), d.getMonth(), 1)), start = mondayOf(first), last = new Date(d.getFullYear(), d.getMonth() + 1, 0), today = isoDate(new Date());
      var weeks = Math.ceil(((parseDate(mondayOf(isoDate(last))) - parseDate(start)) / 86400000 + 7) / 7), byDate = {};
      tickets.forEach(function (t) { var k = monKind(t); if (!k) { return; } var pl = placeOf(t), sl = slotsIn(pl.start, pl.end); if (!sl.length) { return; } (byDate[pl.date] = byDate[pl.date] || []).push({ t: t, kind: k, start: pl.start, end: pl.end }); });
      var h = navHTML(MONTHS[d.getMonth()] + ' ' + d.getFullYear()) + '<div class="mlr-month" style="grid-template-rows:auto repeat(' + weeks + ',minmax(0,1fr))">' + ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(function (n) { return '<div class="mlr-mh">' + n + '</div>'; }).join('');
      for (var i = 0; i < weeks * 7; i++) {
        var iso = addDays(start, i), dd = parseDate(iso), list = (byDate[iso] || []).sort(function (x, y) { return toMin(x.start) - toMin(y.start); });
        h += '<div class="mlr-day-c' + (dd.getMonth() !== d.getMonth() ? ' is-out' : '') + ((dd.getDay() === 0 || dd.getDay() === 6) ? ' is-wk' : '') + (iso === today ? ' is-today' : '') + '"><button type="button" class="mlr-dn" data-day="' + iso + '">' + dd.getDate() + '</button>';
        list.slice(0, 3).forEach(function (it) { h += '<div class="mlr-ml k-' + it.kind + '" title="' + esc(TAG[it.kind]) + '">' + esc(it.start + ' ' + (it.t.group || it.t.title)) + '</div>'; });
        if (list.length > 3) { h += '<button type="button" class="mlr-more" data-day="' + iso + '">+ ' + (list.length - 3) + ' weitere</button>'; }
        h += '</div>';
      }
      body.innerHTML = h + '</div>' + MLR_LEGEND; built = 'month';
    }
    function render(force) {
      $$('.mlr-seg button', wrap).forEach(function (b) { b.classList.toggle('is-on', b.dataset.v === view); });
      if (force && view !== built) { built = ''; }
      if (view === 'day') { renderDay(); } else if (view === 'week') { renderWeek(); } else { renderMonth(); }
    }
    body.addEventListener('click', function (e) {
      var n = e.target.closest('[data-nav]'), d = e.target.closest('[data-day]');
      if (d) { setView('day', d.dataset.day); return; }
      if (!n) { return; }
      var step = +n.dataset.nav, today = isoDate(new Date());
      if (step === 0) { anchor = today; }
      else if (view === 'day') { anchor = addDays(anchor, step); }
      else if (view === 'week') { anchor = addDays(anchor, 7 * step); }
      else { var m = parseDate(anchor); anchor = isoDate(new Date(m.getFullYear(), m.getMonth() + step, 1)); }
      render(false);
    });

    /* ---------- Status (nur für den heutigen Tag) ---------- */
    function renderStatus(now) {
      var el = $m('#mlr-status'); if (!el) { return; }
      var today = isoDate(now);
      if (anchor !== today) { el.innerHTML = ''; el.style.display = 'none'; return; }
      el.style.display = '';
      var nm = now.getHours() * 60 + now.getMinutes(), ns = nm * 60 + now.getSeconds(), items = itemsFor(today);
      var conf = items.filter(function (x) { return x.kind === 'ok'; });
      var cur = conf.filter(function (x) { return toMin(x.start) <= nm && nm < toMin(x.end); })[0];
      var nxt = conf.filter(function (x) { return toMin(x.start) > nm; }).sort(function (a, b) { return toMin(a.start) - toMin(b.start); })[0];
      var slot = CFG.slots.filter(function (s) { return toMin(s.start) <= nm && nm < toMin(s.end); })[0], first = toMin(CFG.slots[0].start), last = toMin(CFG.slots[CFG.slots.length - 1].end);
      var state, title, sub;
      if (cur) { state = 'busy'; title = 'Belegt'; sub = esc(cur.t.group) + ' · ' + esc(cur.t.subject) + ' · bis ' + esc(cur.end) + ' Uhr'; }
      else if (slot && slotBlock(today, slot)) { state = 'blocked'; title = 'Gesperrt'; sub = esc(slotBlock(today, slot).reason); }
      else if (slot) { state = 'free'; title = 'Frei'; sub = 'Slot ' + slot.n + ' · ' + slot.start + '–' + slot.end; }
      else if (nm >= first && nm < last) { state = 'break'; title = 'Pause'; sub = 'Zwischen zwei Slots'; }
      else { state = 'off'; title = 'Geschlossen'; sub = 'Außerhalb der Buchungszeiten'; }
      var next = nxt ? (function () { var diff = toMin(nxt.start) * 60 - ns; return '<div><small>Nächste Buchung · ' + esc(nxt.start) + ' Uhr</small><strong>' + esc(nxt.t.group) + '</strong><span>' + esc([nxt.t.subject, nxt.t.teacher].filter(Boolean).join(' · ')) + ' · in ' + (diff >= 3600 ? Math.floor(diff / 3600) + ':' : '') + pad(Math.floor(diff % 3600 / 60)) + ':' + pad(diff % 60) + '</span></div>'; }()) : '<div><small>Nächste Buchung</small><strong>Heute keine weitere</strong></div>';
      var openN = items.filter(function (x) { return x.kind === 'pending' || x.kind === 'special'; }).length;
      var html = '<div class="is-' + state + '"><small>Aktuelle Raumbelegung</small><strong>' + title + '</strong><span>' + sub + '</span></div>' + next + (openN ? '<p class="mlr-open">' + openN + ' Anfrage' + (openN > 1 ? 'n' : '') + ' heute noch nicht bestätigt</p>' : '');
      if (el.getAttribute('data-h') !== html) { el.setAttribute('data-h', html); el.innerHTML = html; }
    }

    /* ---------- Timer (zeitstempelbasiert: läuft auch bei gedrosselten Hintergrund-Tabs richtig weiter) ---------- */
    var T = { mode: 'idle', totalMs: 300000, remMs: 300000, endAt: 0 }, ctxAudio = null, alarmUntil = 0, alarmTimer = null;
    try { var saved = JSON.parse(localStorage.getItem(TKEY) || 'null'); if (saved && saved.mode) { T = saved; } } catch (e) { /* ignore */ }
    function saveT() { try { localStorage.setItem(TKEY, JSON.stringify(T)); } catch (e) { /* ignore */ } }
    function remaining() { return T.mode === 'run' ? Math.max(0, T.endAt - Date.now()) : T.remMs; }
    function beep() { try { if (!ctxAudio) { return; } var o = ctxAudio.createOscillator(), g = ctxAudio.createGain(); o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.2; o.connect(g); g.connect(ctxAudio.destination); o.start(); o.stop(ctxAudio.currentTime + 0.3); } catch (e) { /* ignore */ } }
    function startAlarm() { $m('#mlr-alarm').hidden = false; alarmUntil = Date.now() + 30000; beep(); clearInterval(alarmTimer); alarmTimer = setInterval(function () { if (Date.now() > alarmUntil) { stopAlarm(); } else { beep(); } }, 1200); }
    function stopAlarm() { clearInterval(alarmTimer); $m('#mlr-alarm').hidden = true; }
    function readSet() { var m = Math.max(0, Math.min(99, +$m('#mlr-tmin').value || 0)), s = Math.max(0, Math.min(59, +$m('#mlr-tsec').value || 0)); return (m * 60 + s) * 1000; }
    function writeSet(ms) { $m('#mlr-tmin').value = Math.floor(ms / 60000); $m('#mlr-tsec').value = Math.floor(ms / 1000) % 60; }
    function bindTimer() {
      $m('#mlr-tgo').addEventListener('click', function () {
        try { if (!ctxAudio && (window.AudioContext || window.webkitAudioContext)) { ctxAudio = new (window.AudioContext || window.webkitAudioContext)(); } if (ctxAudio && ctxAudio.resume) { ctxAudio.resume(); } } catch (e) { /* ignore */ }
        if (T.mode === 'run') { T.remMs = remaining(); T.mode = 'pause'; }
        else if (T.mode === 'pause') { T.endAt = Date.now() + T.remMs; T.mode = 'run'; }
        else { var ms = (T.mode === 'done') ? T.totalMs : readSet(); if (ms < 1000) { return; } T.totalMs = ms; T.remMs = ms; T.endAt = Date.now() + ms; T.mode = 'run'; stopAlarm(); }
        saveT(); tick();
      });
      $m('#mlr-treset').addEventListener('click', function () { stopAlarm(); T.mode = 'idle'; T.remMs = T.totalMs; writeSet(T.totalMs); saveT(); tick(); });
      $$('.mlr-presets button', wrap).forEach(function (b) { b.addEventListener('click', function () { if (T.mode === 'idle' || T.mode === 'done') { $m('#mlr-tmin').value = b.dataset.m; $m('#mlr-tsec').value = 0; T.mode = 'idle'; T.totalMs = readSet(); T.remMs = T.totalMs; saveT(); tick(); } }); });
      ['#mlr-tmin', '#mlr-tsec'].forEach(function (s) { $m(s).addEventListener('input', function () { if (T.mode === 'idle') { T.totalMs = readSet(); T.remMs = T.totalMs; saveT(); tick(); } }); });
      writeSet(T.totalMs);
    }
    $m('#mlr-alarm').addEventListener('click', stopAlarm);
    if (T.mode === 'run' && T.endAt <= Date.now()) { T.mode = 'done'; T.remMs = 0; saveT(); }

    /* ---------- Takt ---------- */
    var lastMin = -1;
    function tick(force) {
      var now = new Date(), rem = remaining(), secs = Math.ceil(rem / 1000);
      if (T.mode === 'run' && rem <= 0) { T.mode = 'done'; T.remMs = 0; saveT(); startAlarm(); secs = 0; }
      var tv = pad(Math.floor(secs / 60)) + ':' + pad(secs % 60);
      $m('#mlr-mini').textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
      $m('#mlr-tmini').textContent = (T.mode === 'run' || T.mode === 'pause') ? 'Timer ' + tv + (T.mode === 'pause' ? ' (Pause)' : '') : '';
      if (built === 'day') {
        $m('#mlr-time').textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
        $m('#mlr-wd').textContent = WDLONG[now.getDay()]; $m('#mlr-date').textContent = now.getDate() + '. ' + MONTHS[now.getMonth()] + ' ' + now.getFullYear();
        $m('#mlr-tval').textContent = tv;
        var tm = $m('#mlr-timer'), state = T.mode === 'done' ? 'done' : (T.mode === 'run' || T.mode === 'pause') ? (secs <= 10 ? 'crit' : secs <= 60 ? 'warn' : 'ok') : 'idle';
        tm.setAttribute('data-state', state); tm.setAttribute('data-mode', T.mode);
        $m('#mlr-tgo').textContent = T.mode === 'run' ? 'Pause' : T.mode === 'pause' ? 'Fortsetzen' : 'Start';
        $m('#mlr-tset').style.visibility = (T.mode === 'idle' || T.mode === 'done') ? 'visible' : 'hidden';
        var a = toMin(CFG.dayStart), b = toMin(CFG.dayEnd), nm = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60, f = Math.max(0, Math.min(1, (nm - a) / (b - a)));
        $m('#mlr-pf').style.width = (f * 100) + '%'; $m('#mlr-pt').textContent = nm < a ? 'Der Tag beginnt um ' + CFG.dayStart + ' Uhr' : nm >= b ? 'Tag beendet' : 'Tagesfortschritt ' + Math.round(f * 100) + ' %';
        renderStatus(now);
      }
      if (force || now.getMinutes() !== lastMin) { lastMin = now.getMinutes(); markNow(now); }
    }
    function markNow(now) {   /* aktuellen Slot hervorheben, ohne neu zu zeichnen */
      var today = isoDate(now), nm = now.getHours() * 60 + now.getMinutes();
      $$('.mlr-cell', wrap).forEach(function (c) {
        var sl = CFG.slots[+c.getAttribute('data-n') - 1], iso = c.getAttribute('data-d');
        c.classList.toggle('is-now', iso === today && toMin(sl.start) <= nm && nm < toMin(sl.end));
        c.classList.toggle('is-past', iso < today || (iso === today && toMin(sl.end) <= nm));
      });
      $$('.mlr-sl', wrap).forEach(function (el) { var sl = CFG.slots[+el.getAttribute('data-n') - 1]; el.classList.toggle('is-now', anchorToday() && toMin(sl.start) <= nm && nm < toMin(sl.end)); });
    }
    function anchorToday() { return view !== 'month' && (view === 'week' ? mondayOf(anchor) === mondayOf(isoDate(new Date())) : anchor === isoDate(new Date())); }
    function conn() {
      var c = $m('#mlr-conn'); c.className = 'mlr-conn' + (offline ? ' is-off' : '');
      c.textContent = offline ? 'Keine Verbindung – Stand ' + (lastOk ? pad(lastOk.getHours()) + ':' + pad(lastOk.getMinutes()) : '–') : (lastOk ? 'Aktualisiert ' + pad(lastOk.getHours()) + ':' + pad(lastOk.getMinutes()) : 'Verbinde …');
    }
    function refresh() {
      loadTickets().then(function (all) { tickets = all; offline = false; lastOk = new Date(); render(false); tick(true); conn(); })
        .catch(function () { offline = true; conn(); });
    }
    render(true); tick(true); conn(); refresh();
    setInterval(function () { tick(false); }, 500);
    setInterval(refresh, CFG.refreshSeconds * 1000);
  }

  /* ---------- Start ---------- */
  function isViewPage() { return /\/mod\/data\/view\.php$/.test(location.pathname); }
  function isListMode() { var p = params(); return !p.get('rid') && p.get('mode') !== 'single' && !p.get('advanced') && !p.get('search') && !$('.mbs-single'); }
  /* Moodle gibt die Listen-Vorlage nur aus, wenn es Einträge gibt. Dashboards hängen sich deshalb selbst in die Seite ein. Mit ?mbs=raw abschaltbar. */
  function mountRoot(k) {
    var host = $('[role="main"]') || $('#region-main') || $('main') || document.body, root = document.createElement('div');
    root.className = 'mbs mbs-list-root'; root.setAttribute('data-mbs', 'list'); root.setAttribute('data-kind', k);
    root.innerHTML = '<div class="mbs-toolbar" id="mbs-toolbar"></div><div class="mbs-cards" id="mbs-cards"></div><p class="mbs-empty" id="mbs-empty" hidden></p>';
    var anchor = $('#maincontent', host);
    if (anchor && anchor.parentNode === host) { host.insertBefore(root, anchor.nextSibling); } else { host.insertBefore(root, host.firstChild); }
    document.body.classList.add('mbs-mounted');
    return root;
  }
  function initList() {
    var k = kind(), mode = params().get('mbs');
    if (mode === 'raw') { return; }
    var root = $('.mbs-list-root');
    if (!root && isViewPage() && isListMode()) { root = mountRoot(k); }
    if (!root) { return; }
    if (mode === 'room') { return monitor(root); }
    if (k === 'display') { return planView(root); }
    if (k === 'review') { return adminDashboard(root); }
    return requestsList(root);
  }
  function boot() {
    try { initAdd(); } catch (e) { if (window.console) { console.error('[mbs] add', e); } }
    try { initList(); } catch (e) { if (window.console) { console.error('[mbs] list', e); } }
    try { initSingle(); } catch (e) { if (window.console) { console.error('[mbs] single', e); } }
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
}());
