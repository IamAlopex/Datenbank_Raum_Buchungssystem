/* Moodle Media Lab Booking System v3.0 – JavaScript-Vorlage (gleicher Code in allen drei Aktivitäten)
 * Reines Vanilla-JS, keine externen Bibliotheken.
 * Wichtig zur Rollenverteilung: Alles Gespeicherte wird von MOODLE gespeichert und per Moodle-Rechten geschützt
 * (Formular-Speichern, native Freigabe). Dieses Skript bedient diese Funktionen nur komfortabel, es speichert nichts lokal.
 * Rollen: requests = Buchungsportal + einzige Datenquelle, review = Administrations-Dashboard, display = Raumplan/Monitor.
 */
(function () {
  'use strict';

  var PRESET_KIND = 'requests'; /* wird beim Bau je Preset gesetzt: requests | review | display */

  var CFG = {
    /* ZENTRALE SLOT-DEFINITION (wird beim Bau aus derselben Quelle erzeugt wie die Menüoptionen der Felder
     * preferred_start / preferred_end / approved_start / approved_end). special = nur auf Spezialanfrage. */
    slots: [{"n": 1, "start": "08:00", "end": "08:45", "special": false}, {"n": 2, "start": "08:45", "end": "09:30", "special": false}, {"n": 3, "start": "09:50", "end": "10:35", "special": false}, {"n": 4, "start": "10:35", "end": "11:20", "special": false}, {"n": 5, "start": "11:40", "end": "12:25", "special": false}, {"n": 6, "start": "12:25", "end": "13:15", "special": false}, {"n": 7, "start": "13:45", "end": "14:30", "special": true}, {"n": 8, "start": "14:30", "end": "15:15", "special": false}, {"n": 9, "start": "15:15", "end": "16:00", "special": false}],
    weekdays: [1, 2, 3, 4, 5],                       /* Montag bis Freitag; 0 = Sonntag */
    /* Sperrregeln je Wochentag (JS-Wochentag: 3 = Mittwoch, 5 = Freitag). Ein Slot ist gesperrt, wenn er ab `from` beginnt. */
    limits: {
      3: { from: '13:15', note: 'Ab 13:15 Uhr – Keine Buchungen möglich' },
      5: { from: '13:15', until: '15:30', label: 'Social Media AG', note: 'Ab 13:15 Uhr – Keine Buchungen möglich' }
    },
    dayStart: '08:00', dayEnd: '16:00',
    refreshSeconds: 30,
    roomName: 'Media Lab',
    approvedLabel: 'Genehmigt', pendingLabel: 'Ausstehend', rejectedLabel: 'Abgelehnt',
    altLabel: 'Alternativtermin vorgeschlagen', cancelledLabel: 'Storniert',
    specialLabel: 'Spezialanfrage', regularLabel: 'Regulär',
    monitor: { showPending: true, showRejected: true },
    /* Die Schwester-Aktivitäten werden im Kurs über den Namen gefunden. Klappt das nicht: Kursmodul-IDs (cmid) eintragen. */
    names: { requests: 'booking_requests', review: 'booking_review', display: 'room_display' },
    ids: { requests: 0, review: 0, display: 0 }
  };
  var STATUS = [CFG.pendingLabel, CFG.approvedLabel, CFG.rejectedLabel, CFG.altLabel, CFG.cancelledLabel];

  /* ---------- Helfer ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function isoDateTime(d) { return isoDate(d) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function toMin(t) { var m = /^(\d{1,2}):(\d{2})/.exec(String(t || '').trim()); return m ? (+m[1]) * 60 + (+m[2]) : NaN; }
  function fromMin(n) { return pad(Math.floor(n / 60)) + ':' + pad(n % 60); }
  function normDate(s) {
    s = String(s || '').trim();
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(s);
    if (m) { return m[1] + '-' + pad(+m[2]) + '-' + pad(+m[3]); }
    m = /^(\d{1,2})\.(\d{1,2})\.(\d{4})/.exec(s);
    if (m) { return m[3] + '-' + pad(+m[2]) + '-' + pad(+m[1]); }
    return s;
  }
  function parseDate(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; }
  function wdName(iso) { var d = parseDate(iso); return d ? ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d.getDay()] : ''; }
  function fmtDate(iso) { var d = parseDate(iso); return d ? wdName(iso) + ', ' + pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() : (iso || ''); }
  function overlaps(a1, a2, b1, b2) { return a1 < b2 && b1 < a2; }
  function params() { return new URLSearchParams(location.search); }
  function kind() { if (PRESET_KIND) { return PRESET_KIND; } var n = $('[data-kind]'); return n ? n.getAttribute('data-kind') : ''; }
  function siteRoot() { return location.pathname.replace(/\/mod\/data\/[^\/]*$/, ''); }
  function baseDir() { return location.pathname.replace(/[^\/]*$/, ''); }
  function dbQuery() {
    var p = params();
    if (p.get('d')) { return 'd=' + encodeURIComponent(p.get('d')); }
    if (p.get('id')) { return 'id=' + encodeURIComponent(p.get('id')); }
    return '';
  }
  function viewUrl(extra) { return baseDir() + 'view.php?' + dbQuery() + (extra ? '&' + extra : ''); }
  function addUrl() { return baseDir() + 'edit.php?' + dbQuery(); }
  function viewByCm(cm, extra) { return siteRoot() + '/mod/data/view.php?id=' + encodeURIComponent(cm) + (extra ? '&' + extra : ''); }

  /* Reine Oberflächen-Erkennung (KEINE Sicherheitsfunktion). */
  function isAdmin() {
    return !!$('a[href*="/mod/data/field.php"], a[href*="/mod/data/templates.php"], a[href*="/mod/data/preset.php"], a[href*="/mod/data/presets.php"]');
  }
  function currentUserName() {
    var n = $('.usermenu .usertext') || $('#user-menu-toggle .usertext') || $('.usermenu .userbutton');
    return n ? n.textContent.replace(/\s+/g, ' ').trim() : '';
  }
  function courseId() {
    if (window.M && M.cfg && M.cfg.courseId && +M.cfg.courseId > 1) { return String(M.cfg.courseId); }
    var a = $('a[href*="/course/view.php?id="]'), m = a && /[?&]id=(\d+)/.exec(a.getAttribute('href'));
    return m ? m[1] : '';
  }
  function discover(role) {
    if (CFG.ids[role]) { return Promise.resolve(String(CFG.ids[role])); }
    var key = 'mbs_v3_cm_' + role, cached = '';
    try { cached = sessionStorage.getItem(key) || ''; } catch (e) { /* ignore */ }
    if (cached) { return Promise.resolve(cached); }
    var cid = courseId(); if (!cid) { return Promise.resolve(''); }
    return fetch(siteRoot() + '/course/view.php?id=' + encodeURIComponent(cid), { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.text() : ''; })
      .then(function (t) {
        if (!t) { return ''; }
        var doc = new DOMParser().parseFromString(t, 'text/html'), found = '', want = CFG.names[role].toLowerCase();
        $$('a[href*="/mod/data/view.php?id="]', doc).some(function (a) {
          var inst = $('.instancename', a), txt = ((inst && inst.firstChild ? inst.firstChild.textContent : a.textContent) || '').trim().toLowerCase();
          var m = /[?&]id=(\d+)/.exec(a.getAttribute('href'));
          if (m && txt.indexOf(want) === 0) { found = m[1]; return true; }
          return false;
        });
        if (found) { try { sessionStorage.setItem(key, found); } catch (e) { /* ignore */ } }
        return found;
      }).catch(function () { return ''; });
  }

  /* =====================================================================
   * Slots und Sperrregeln (zentral, siehe CFG)
   * ===================================================================== */
  function slotsIn(start, end) {
    var s = toMin(start), e = toMin(end);
    if (isNaN(s) || isNaN(e)) { return []; }
    return CFG.slots.filter(function (sl) { return toMin(sl.start) >= s && toMin(sl.end) <= e; });
  }
  function slotLabel(list) {
    if (!list.length) { return ''; }
    var a = list[0], b = list[list.length - 1];
    return (a.n === b.n ? 'Slot ' + a.n : 'Slot ' + a.n + '–' + b.n) + ' · ' + a.start + '–' + b.end;
  }
  function timeLabel(start, end) {
    var l = slotsIn(start, end);
    if (l.length) { return slotLabel(l); }
    return (start && end) ? start + '–' + end : 'Zeit nach Absprache';
  }
  /* Ist dieser Slot an diesem Datum grundsätzlich nicht regulär buchbar? → { reason, ag } oder null */
  function slotBlock(iso, sl) {
    var d = parseDate(iso); if (!d) { return { reason: 'Kein gültiges Datum' }; }
    var wd = d.getDay();
    if (CFG.weekdays.indexOf(wd) < 0) { return { reason: 'Am Wochenende nicht buchbar' }; }
    var l = CFG.limits[wd];
    if (l && toMin(sl.start) >= toMin(l.from)) { return { reason: l.label ? l.label + ' (' + l.from + '–' + l.until + ' Uhr)' : l.note, ag: !!l.label }; }
    return null;
  }
  function isSpecialRange(start, end) { return slotsIn(start, end).some(function (s) { return s.special; }); }

  /* =====================================================================
   * Ticket-Modell (aus den Karten der Listen-Vorlage)
   * ===================================================================== */
  /* Freigabe-Erkennung: verlassen kann man sich nur auf das, was Moodle je nach Recht ausgibt.
   *  - Link „disapprove=…“ → freigegeben;  Link „approve=…“ → offen (beide nur für Freigebende sichtbar)
   *  - Sonst liefert Moodle fremde Einträge nur, wenn sie freigegeben sind; eigene offene erkennt man an Bearbeiten-/Löschen-Links
   *    (bei „genehmigte Einträge nicht änderbar“) bzw. am Moodle-Text. Im Zweifel: NICHT freigegeben. */
  function approvalOf(node) {
    var links = {};
    $$('a[href]', node).forEach(function (a) {
      var h = a.getAttribute('href') || '';
      if (/[?&]disapprove=/.test(h)) { links.disapprove = h; }
      else if (/[?&]approve=/.test(h)) { links.approve = h; }
      else if (/[?&]delete=/.test(h)) { links.del = h; }
      else if (/\/edit\.php/.test(h)) { links.edit = h; }
    });
    var src = $('.mbs-approval-src', node), txt = '';
    if (src) {
      txt = src.textContent + ' ' + $$('[title],[alt],[aria-label]', src).map(function (x) { return (x.getAttribute('title') || '') + ' ' + (x.getAttribute('alt') || '') + ' ' + (x.getAttribute('aria-label') || ''); }).join(' ');
    }
    var pendingTxt = /(^|[^a-zäöüß])(nicht|not|pending|ausstehend|wartet|unapproved|ungenehmigt|notapproved)([^a-zäöüß]|$)/i.test(txt);
    var canEdit = !!(links.edit || links.del), approved;
    if (links.disapprove) { approved = true; }
    else if (links.approve || pendingTxt || canEdit) { approved = false; }
    else { approved = true; }
    return { approved: approved, canEdit: canEdit, links: links };
  }
  function txt(n, sel, keepNl) {
    var e = $(sel, n); if (!e) { return ''; }
    return keepNl ? e.textContent.trim() : e.textContent.replace(/\s+/g, ' ').trim();
  }
  function parseTicket(n) {
    var d = n.dataset, ap = approvalOf(n), act = $('.mbs-src-activities', n), list = [];
    if (act) {
      var c = act.cloneNode(true);
      $$('br', c).forEach(function (b) { b.parentNode.replaceChild(document.createTextNode('|'), b); });
      list = c.textContent.split('|').map(function (s) { return s.replace(/\s+/g, ' ').trim(); }).filter(Boolean);
    }
    return {
      node: n, id: d.id,
      group: (d.group || '').trim(), subject: (d.subject || '').trim(), teacher: (d.teacher || '').trim(), title: (d.title || '').trim(),
      type: (d.type || '').trim(), room: (d.room || '').trim(),
      date: normDate(d.date), start: (d.start || '').trim(), end: (d.end || '').trim(),
      altdate: normDate(d.altdate), alttime: (d.alttime || '').trim(), custom: (d.custom || '').trim() === 'Ja',
      duration: (d.duration || '').trim(), status: (d.status || '').trim() || CFG.pendingLabel,
      adate: normDate(d.adate), astart: (d.astart || '').trim(), aend: (d.aend || '').trim(),
      created: (d.created || '').trim(), approvedBy: (d.approvedby || '').trim(), approvalDate: (d.approvaldate || '').trim(),
      activities: list, desc: txt(n, '.mbs-src-desc', true), reason: txt(n, '.mbs-comment-text', true),
      by: txt(n, '.mbs-by-name'), added: txt(n, '.mbs-added'),
      approved: ap.approved, canEdit: ap.canEdit, links: ap.links
    };
  }
  function readTickets(root) { return $$('.mbs-card[data-id]', root).map(parseTicket); }

  function wish(t) { return { date: t.date, start: t.start, end: t.end }; }
  function binding(t) {
    if (t.status === CFG.approvedLabel && t.adate && t.astart && t.aend) { return { date: t.adate, start: t.astart, end: t.aend }; }
    return wish(t);
  }
  function proposalOf(t) { return (t.status === CFG.altLabel && t.adate && t.astart && t.aend) ? { date: t.adate, start: t.astart, end: t.aend } : null; }
  function isConfirmed(t) { return t.approved && t.status === CFG.approvedLabel; }   /* Moodle-Freigabe UND Status */
  function isSpecial(t) { var w = wish(t); return t.type === CFG.specialLabel || isSpecialRange(w.start, w.end); }
  function placeOf(t) { return isConfirmed(t) ? binding(t) : wish(t); }
  function shortActivity(a) { return String(a).replace(/\s*\(.*$/, '').trim(); }
  function conflictsWith(all, place, exceptId) {
    var s = toMin(place.start), e = toMin(place.end);
    return all.filter(function (t) {
      if (String(t.id) === String(exceptId) || !isConfirmed(t)) { return false; }
      var b = binding(t);
      return b.date === place.date && !isNaN(toMin(b.start)) && !isNaN(toMin(b.end)) && overlaps(s, e, toMin(b.start), toMin(b.end));
    });
  }

  /* ---------- Laden (die Tickets liegen ausschließlich in booking_requests) ---------- */
  function fetchDocument(url) {
    return fetch(url, { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok || /\/login\//.test(r.url)) { throw new Error('Nicht angemeldet oder Server nicht erreichbar'); }
      return r.text();
    }).then(function (t) { return new DOMParser().parseFromString(t, 'text/html'); });
  }
  function sourceUrl() {
    var tail = 'mode=list&perpage=1000';
    if (kind() === 'requests') { return Promise.resolve(viewUrl(tail)); }
    return discover('requests').then(function (cm) {
      if (!cm) { throw new Error('Aktivität „' + CFG.names.requests + '“ wurde im Kurs nicht gefunden. Name prüfen oder CFG.ids in der JavaScript-Vorlage setzen.'); }
      return viewByCm(cm, tail);
    });
  }
  function loadRequestCards() {
    return sourceUrl().then(function (url) {
      return fetchDocument(url).then(function (doc) {
        return $$('.mbs-card[data-id]', doc).map(function (card) {
          $$('a[href]', card).forEach(function (a) {
            var href = a.getAttribute('href');
            if (href && !/^(?:[a-z][a-z0-9+.-]*:|#|\/\/)/i.test(href)) { a.setAttribute('href', new URL(href, location.origin + url).href); }
          });
          return card;
        });
      });
    });
  }
  function loadTickets() {
    return loadRequestCards().then(function (nodes) {
      var holder = document.createElement('div');
      nodes.forEach(function (n) { holder.appendChild(document.importNode(n, true)); });
      return readTickets(holder);
    });
  }
  function sourceError(root, message) {
    var box = $('.mbs-toolbar', root);
    if (box) { box.innerHTML = '<div class="mbs-banner mbs-banner-warn"><strong>Verbindung nicht verfügbar.</strong> ' + esc(message) + '</div>'; }
    var empty = $('#mbs-empty', root); if (empty) { empty.hidden = false; empty.textContent = 'Die Quelldatenbank konnte nicht geladen werden.'; }
  }

  /* =====================================================================
   * 1) BUCHUNGSPORTAL – sechs Fragen im Add-Template
   * ===================================================================== */
  function makeForm(root) {
    var F = {};
    F.wrap = function (n) { return $('[data-mbs-field="' + n + '"]', root); };
    F.inp = function (n) { var w = F.wrap(n); return w && w.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),select,textarea'); };
    F.val = function (n) {
      var i = F.inp(n); if (!i) { return ''; }
      if (i.tagName === 'SELECT') { return i.value ? i.options[i.selectedIndex].text.trim() : ''; }
      return (i.value || '').trim();
    };
    F.setVal = function (n, v) {
      var w = F.wrap(n); if (!w) { return; }
      var rs = $$('input[type=radio]', w);
      if (rs.length) {
        rs.forEach(function (r) {
          var l = $('label[for="' + r.id + '"]', root), t = (r.value + ' ' + (l ? l.textContent : '')).trim();
          r.checked = (r.value === v) || t.split(/\s+/).indexOf(v) > -1;
        });
        return;
      }
      var i = F.inp(n); if (!i) { return; }
      if (i.tagName === 'SELECT') {
        i.selectedIndex = 0;
        for (var k = 0; k < i.options.length; k++) { if (v !== '' && (i.options[k].text.trim() === v || i.options[k].value === v)) { i.selectedIndex = k; break; } }
      } else { i.value = v; }
      i.dispatchEvent(new Event('change', { bubbles: true }));
    };
    F.setIfEmpty = function (n, v) { if (!F.val(n) && v !== '' && v != null) { F.setVal(n, String(v)); } };
    F.checks = function (n) { return $$('input[type=checkbox]', F.wrap(n) || root); };
    F.label = function (c) { var l = $('label[for="' + c.id + '"]', root); return l ? l.textContent.trim() : c.value; };
    return F;
  }

  function initAdd() {
    var root = $('#mbs-add'); if (!root || kind() !== 'requests') { return; }
    var form = root.closest('form') || document;
    function unlock() { $$('input[type=submit], button[type=submit]', form).forEach(function (b) { b.disabled = false; }); }
    try { runForm(root, form); } catch (e) {
      if (window.console) { console.error('[mbs]', e); }
      root.classList.remove('mbs-js'); unlock();   /* Fallback: normales Moodle-Formular */
    }
  }

  function runForm(root, form) {
    root.classList.add('mbs-js');
    var F = makeForm(root), editing = !!params().get('rid'), admin = isAdmin();
    var today = isoDate(new Date()), busy = [], busyKnown = false, sel = null;   /* sel = { date, i, N } */

    /* Datumsfelder: Texteingabe → native Datumsauswahl (liefert ISO) */
    ['preferred_date', 'alternative_date', 'approved_date'].forEach(function (n) {
      var i = F.inp(n);
      if (i) {
        i.type = 'date'; i.value = normDate(i.value);
        var hint = i.parentNode && i.parentNode.querySelector('.mbs-hint'); if (hint) { hint.hidden = true; }
        if (n !== 'approved_date' && !editing) { i.min = today; }
      }
    });
    if (admin) { var ab = $('#mbs-admin', root); if (ab) { ab.hidden = false; } }

    /* Automatisch gesetzte Felder (nur bei neuen Anfragen bzw. wenn leer) */
    F.setIfEmpty('room', CFG.roomName);
    F.setIfEmpty('booking_status', CFG.pendingLabel);
    F.setIfEmpty('created_at', isoDateTime(new Date()));

    /* Frage 3: Auswahlkarten (Mehrfachauswahl) */
    $$('br', F.wrap('activities') || root).forEach(function (b) { b.parentNode.removeChild(b); });
    F.checks('activities').forEach(function (c) {
      var l = $('label[for="' + c.id + '"]', root); if (!l) { return; }
      l.classList.add('mbs-choice');
      function sync() { l.classList.toggle('is-on', c.checked); }
      c.addEventListener('change', function () { sync(); summary(); });
      c.addEventListener('focus', function () { l.classList.add('is-focus'); });
      c.addEventListener('blur', function () { l.classList.remove('is-focus'); });
      sync();
    });

    /* Frage 5: Dauer als Karten (das Menüfeld bleibt die gespeicherte Quelle) */
    var dsel = F.inp('duration'), dbox = null;
    function durN() { var m = /^(\d)\s*Slot/.exec(F.val('duration')); return m ? +m[1] : 0; }
    if (dsel) {
      dsel.style.display = 'none';
      dbox = document.createElement('div'); dbox.className = 'mbs-pickrow';
      for (var k = 0; k < dsel.options.length; k++) {
        if (!dsel.options[k].value && !dsel.options[k].text.trim()) { continue; }
        if (/^(choose|wählen|auswahl|\.\.\.)/i.test(dsel.options[k].text.trim()) || dsel.options[k].value === '') { continue; }
        (function (txt) {
          var b = document.createElement('button'); b.type = 'button'; b.className = 'mbs-pick'; b.textContent = txt;
          b.addEventListener('click', function () { F.setVal('duration', txt); sel = null; syncDur(); renderWindows(); summary(); });
          dbox.appendChild(b);
        }(dsel.options[k].text.trim()));
      }
      dsel.parentNode.insertBefore(dbox, dsel.nextSibling);
    }
    function syncDur() { if (!dbox) { return; } $$('.mbs-pick', dbox).forEach(function (b) { b.classList.toggle('is-on', b.textContent === F.val('duration')); }); }
    syncDur();

    /* Frage 6: Datum → Zeitfenster aus den zentral definierten Slots */
    var wbox = $('#mbs-windows', root), toggle = $('#mbs-custom-toggle', root), cbox = $('#mbs-custom-box', root);
    function customOn() { return toggle.checked; }
    function setCustom(on) {
      toggle.checked = on; cbox.hidden = !on;
      F.setVal('is_custom_request', on ? 'Ja' : 'Nein');
      if (on) { sel = null; } else { F.setVal('alternative_date', ''); F.setVal('alternative_time', ''); }
      renderWindows(); summary();
    }
    toggle.addEventListener('change', function () { setCustom(toggle.checked); });
    var wasCustom = $$('input[type=radio]', F.wrap('is_custom_request') || root).some(function (r) { return r.checked && r.value === 'Ja'; });
    toggle.checked = wasCustom; cbox.hidden = !wasCustom;

    function windowInfo(iso, i, N, nowMin) {
      var sls = CFG.slots.slice(i, i + N); if (sls.length < N) { return null; }
      var blocked = '', occupied = false, special = false;
      sls.forEach(function (sl) {
        var b = slotBlock(iso, sl); if (b && !blocked) { blocked = b.reason; }
        if (sl.special) { special = true; }
        if (busy.some(function (t) { var p = binding(t); return p.date === iso && overlaps(toMin(sl.start), toMin(sl.end), toMin(p.start), toMin(p.end)); })) { occupied = true; }
      });
      var start = sls[0].start, end = sls[sls.length - 1].end, past = iso === today && toMin(start) <= nowMin;
      var cls = blocked ? 'blocked' : occupied ? 'busy' : past ? 'past' : special ? 'special' : 'free';
      return { i: i, N: N, start: start, end: end, cls: cls, label: slotLabel(sls),
        note: blocked || (occupied ? 'bereits belegt' : past ? 'schon vorbei' : special ? 'nur auf Spezialanfrage' : 'frei') };
    }
    function dateProblem(iso) {
      var d = parseDate(iso);
      if (!d) { return 'Bitte wählt ein Datum.'; }
      if (iso < today && !editing) { return 'Das Datum liegt in der Vergangenheit.'; }
      if (CFG.weekdays.indexOf(d.getDay()) < 0) { return 'Am Wochenende ist das Media Lab nicht buchbar.'; }
      return '';
    }
    function renderWindows() {
      if (!wbox) { return; }
      if (customOn()) { wbox.innerHTML = ''; return; }
      var iso = normDate(F.val('preferred_date')), N = durN(), h = '';
      if (!F.val('duration')) { wbox.innerHTML = '<p class="mbs-note">Wählt zuerst bei Frage 5, wie viel Zeit ihr braucht.</p>'; return; }
      if (!N) { wbox.innerHTML = '<p class="mbs-note">Bei längeren Vorhaben legt die Media-Lab-Leitung die Zeit fest. Wählt trotzdem euer Wunschdatum.</p>'; return; }
      var prob = dateProblem(iso);
      if (prob) { wbox.innerHTML = '<p class="mbs-note">' + esc(prob) + '</p>'; return; }
      var now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes(), any = false, lim = CFG.limits[parseDate(iso).getDay()];
      h += '<div class="mbs-wintitle">Zeitfenster am ' + esc(fmtDate(iso)) + '</div>';
      if (lim) { h += '<p class="mbs-note is-info">' + esc(lim.label ? lim.from + '–' + lim.until + ' Uhr – ' + lim.label + '. ' + lim.note : lim.note) + '</p>'; }
      h += '<div class="mbs-wingrid">';
      for (var i = 0; i + N <= CFG.slots.length; i++) {
        var w = windowInfo(iso, i, N, nowMin); if (!w) { continue; }
        var on = sel && sel.date === iso && sel.i === i && sel.N === N, usable = (w.cls === 'free' || w.cls === 'special');
        if (usable) { any = true; }
        h += '<button type="button" class="mbs-win is-' + w.cls + (on ? ' is-on' : '') + '" data-i="' + i + '"' + (usable ? '' : ' disabled') + '><b>' + esc(w.label) + '</b><span>' + esc(w.note) + '</span></button>';
      }
      h += '</div>';
      if (!any) { h += '<p class="mbs-note">An diesem Tag gibt es kein regulär buchbares Zeitfenster dieser Länge. Wählt ein anderes Datum oder schlagt einen eigenen Termin vor.</p>'; }
      h += '<p class="mbs-note">' + (busyKnown ? 'Als „belegt“ markiert sind bereits genehmigte Buchungen.' : 'Belegungshinweise konnten nicht geladen werden.') + ' Das ist ein Hinweis, keine Zusage: Die Media-Lab-Leitung prüft jede Anfrage.</p>';
      wbox.innerHTML = h;
    }
    if (wbox) {
      wbox.addEventListener('click', function (ev) {
        var b = ev.target.closest('.mbs-win'); if (!b || b.disabled) { return; }
        sel = { date: normDate(F.val('preferred_date')), i: +b.dataset.i, N: durN() }; renderWindows(); summary();
      });
    }
    ['preferred_date', 'alternative_date', 'alternative_time', 'user_name', 'subject', 'teacher', 'description'].forEach(function (n) {
      var i = F.inp(n); if (!i) { return; }
      i.addEventListener('change', function () { if (n === 'preferred_date') { sel = null; renderWindows(); } summary(); });
      i.addEventListener('input', summary);
    });

    /* Belegte Zeiten: nur genehmigte Buchungen (Hinweis im Browser, keine Zusage) */
    loadTickets().then(function (list) { busy = list.filter(isConfirmed); busyKnown = true; renderWindows(); })
      .catch(function () { busyKnown = false; renderWindows(); });

    /* ---------- Zusammenfassung, Prüfung, Absenden ---------- */
    function chosenActivities() { return F.checks('activities').filter(function (c) { return c.checked; }).map(F.label); }
    function currentWindow() {
      if (!sel || customOn()) { return null; }
      var sls = CFG.slots.slice(sel.i, sel.i + sel.N); if (sls.length !== sel.N) { return null; }
      return { date: sel.date, start: sls[0].start, end: sls[sls.length - 1].end, label: slotLabel(sls), special: sls.some(function (s) { return s.special; }) };
    }
    function summary() {
      var box = $('#mbs-summary', root); if (!box) { return; }
      var w = currentWindow(), acts = chosenActivities(), rows = [
        ['Wer', F.val('user_name') || '–'], ['Fach / Lehrkraft', (F.val('subject') || '–') + ' / ' + (F.val('teacher') || '–')],
        ['Vorhaben', acts.map(shortActivity).join(', ') || '–'], ['Idee', F.val('description') || '–'], ['Benötigte Zeit', F.val('duration') || '–']];
      if (customOn()) { rows.push(['Wunschtermin', 'Eigener Vorschlag: ' + (fmtDate(normDate(F.val('alternative_date'))) || '–') + (F.val('alternative_time') ? ' (' + F.val('alternative_time') + ')' : '')]); }
      else { rows.push(['Wunschtermin', w ? fmtDate(w.date) + ' · ' + w.label + (w.special ? ' (Spezialanfrage)' : '') : (F.val('preferred_date') ? fmtDate(normDate(F.val('preferred_date'))) + ' · Zeit noch nicht gewählt' : '–')]); }
      box.innerHTML = '<dl>' + rows.map(function (r) { return '<dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd>'; }).join('') + '</dl>';
    }
    function validate() {
      var e = [];
      if (!F.val('user_name')) { e.push('Frage 1: Bitte gebt euren Gruppennamen bzw. die Namen der Beteiligten an.'); }
      if (!F.val('subject')) { e.push('Frage 2: Bitte nennt das Fach.'); }
      if (!F.val('teacher')) { e.push('Frage 2: Bitte nennt die zuständige Lehrkraft.'); }
      if (!chosenActivities().length) { e.push('Frage 3: Bitte wählt mindestens eine Tätigkeit.'); }
      if (!F.val('description')) { e.push('Frage 4: Bitte beschreibt eure Idee in 1–2 Sätzen.'); }
      if (!F.val('duration')) { e.push('Frage 5: Bitte wählt, wie viel Zeit ihr braucht.'); }
      if (editing) { return e; }   /* bestehende Anfragen (z. B. durch die Verwaltung) nicht neu bewerten */
      if (customOn()) {
        var ad = normDate(F.val('alternative_date')), p = dateProblem(ad);
        if (p) { e.push('Frage 6: Eigener Wunschtermin – ' + p); }
      } else {
        var pd = dateProblem(normDate(F.val('preferred_date')));
        if (pd) { e.push('Frage 6: ' + pd); }
        else if (durN() && !currentWindow()) { e.push('Frage 6: Bitte wählt ein Zeitfenster oder schlagt einen eigenen Termin vor.'); }
      }
      return e;
    }
    function compose() {
      var acts = chosenActivities().map(shortActivity), w = currentWindow();
      F.setVal('room', CFG.roomName);
      F.setVal('booking_title', (F.val('user_name') + ' – ' + (acts.join(', ') || 'Media Lab')).slice(0, 250));
      if (!editing || w || customOn()) {
        if (customOn()) {
          F.setVal('preferred_date', normDate(F.val('alternative_date'))); F.setVal('preferred_start', ''); F.setVal('preferred_end', ''); F.setVal('booking_type', CFG.regularLabel);
        } else if (w) {
          F.setVal('preferred_date', w.date); F.setVal('preferred_start', w.start); F.setVal('preferred_end', w.end); F.setVal('booking_type', w.special ? CFG.specialLabel : CFG.regularLabel);
        }
      }
      F.setVal('is_custom_request', customOn() ? 'Ja' : 'Nein');
    }
    var err = $('#mbs-error', root);
    form.addEventListener('submit', function (ev) {
      var e = validate();
      if (e.length) {
        ev.preventDefault();
        err.innerHTML = '<strong>Bitte vervollständigen:</strong><ul>' + e.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>'; err.hidden = false;
        err.scrollIntoView({ block: 'center' }); return;
      }
      err.hidden = true; compose();
      try { sessionStorage.setItem('mbs_submitted', '1'); } catch (x) { /* ignorieren */ }
    });

    /* Bestehende Anfrage bearbeiten: Fenster wiederherstellen */
    var pd0 = normDate(F.val('preferred_date')), ps = F.val('preferred_start'), pe = F.val('preferred_end');
    if (pd0 && ps && pe && !wasCustom) {
      var existing = slotsIn(ps, pe);
      if (existing.length) { sel = { date: pd0, i: CFG.slots.indexOf(existing[0]), N: existing.length }; }
    }
    renderWindows(); summary();
  }

  /* =====================================================================
   * 2) Liste in booking_requests (Studierende): eigene Anfragen mit Status
   * ===================================================================== */
  function decorateCard(t) {
    var n = t.node, sl = $('.mbs-slotlabel', n);
    if (sl) { sl.textContent = (t.custom && !t.start) ? 'Eigener Terminvorschlag' : timeLabel(t.start, t.end); }
    var ap = $('.mbs-approval', n);
    if (ap) { ap.textContent = t.approved ? 'Freigegeben' : 'Freigabe ausstehend'; ap.setAttribute('data-approved', t.approved ? '1' : '0'); }
    var pr = proposalOf(t), box = $('.mbs-proposal', n);
    if (pr && box) { box.hidden = false; box.innerHTML = '<b>Vorschlag der Media-Lab-Leitung:</b> ' + esc(fmtDate(pr.date) + ' · ' + timeLabel(pr.start, pr.end)); }
    var cm = $('.mbs-comment', n);
    if (cm && (!$('.mbs-comment-text', cm).textContent.trim() || !t.canEdit)) { cm.classList.add('is-empty'); }   /* Rückmeldung nur für Ersteller/Verwaltung */
  }
  function requestsList(root) {
    var tickets = readTickets(root), bar = $('#mbs-toolbar', root), banner = '', admin = isAdmin();
    tickets.forEach(decorateCard);
    try {
      if (sessionStorage.getItem('mbs_submitted')) {
        sessionStorage.removeItem('mbs_submitted');
        banner = '<div class="mbs-banner"><strong>Anfrage gespeichert.</strong> Sie ist noch keine Buchungsbestätigung. Die Media-Lab-Leitung meldet sich bzw. entscheidet; den Stand seht ihr hier.</div>';
      }
    } catch (e) { /* ignorieren */ }
    bar.innerHTML = banner + '<div class="mbs-top"><h2>' + (admin ? 'Alle Anfragen' : 'Meine Anfragen') + '</h2><div class="mbs-topbtns">' +
      (admin ? '<a class="mbs-btn mbs-btn-ghost" id="mbs-to-review" href="#" style="display:none">Zum Prüf-Dashboard</a>' : '') +
      '<a class="mbs-btn mbs-btn-primary" href="' + esc(addUrl()) + '">Media Lab buchen</a></div></div>' +
      '<p class="mbs-note">Eine Anfrage ist keine Buchungsbestätigung. Freigegebene Buchungen sind für den Kurs sichtbar, offene Anfragen nur für euch und die Media-Lab-Leitung.</p>';
    if (admin) { discover('review').then(function (cm) { var a = $('#mbs-to-review'); if (cm && a) { a.href = viewByCm(cm); a.style.display = ''; } }); }
    var empty = $('#mbs-empty'); if (empty) { empty.hidden = tickets.length > 0; empty.textContent = 'Noch keine Anfragen vorhanden.'; }
  }

  /* Raumplan (Aktivität room_display, ohne Vollbild): bestätigte Buchungen ab heute */
  function planView(root) {
    var box = $('#mbs-cards', root), bar = $('#mbs-toolbar', root);
    loadTickets().then(function (all) {
      var today = isoDate(new Date());
      var list = all.filter(function (t) { return isConfirmed(t) && binding(t).date >= today; }).sort(function (a, b) {
        var x = binding(a), y = binding(b); return (x.date + x.start) < (y.date + y.start) ? -1 : 1;
      });
      bar.innerHTML = '<div class="mbs-top"><h2>Media Lab · Raumplan</h2><a class="mbs-btn mbs-btn-primary" href="' + esc(viewUrl('mbs=room')) + '" target="_blank" rel="noopener">Monitor starten</a></div>' +
        '<p class="mbs-note">Angezeigt werden nur bestätigte Buchungen (Moodle-Freigabe und Status „Genehmigt“).</p>';
      box.innerHTML = list.map(function (t) {
        var b = binding(t);
        return '<article class="mbs-card" data-status="Genehmigt"><header class="mbs-card-head"><span class="mbs-badge">Bestätigt</span></header>' +
          '<h3 class="mbs-card-title">' + esc(t.group) + '</h3><p class="mbs-sub">' + esc(t.subject) + ' · ' + esc(t.teacher) + '</p>' +
          '<ul class="mbs-meta"><li><span>Datum</span><strong>' + esc(fmtDate(b.date)) + '</strong></li><li><span>Zeit</span><strong>' + esc(timeLabel(b.start, b.end)) + '</strong></li></ul></article>';
      }).join('');
      var empty = $('#mbs-empty'); if (empty) { empty.hidden = list.length > 0; empty.textContent = 'Keine bestätigten Buchungen ab heute.'; }
    }).catch(function (e) { sourceError(root, e.message); });
  }

  /* =====================================================================
   * 3) ADMINISTRATIONS-DASHBOARD (Aktivität booking_review)
   *    Live-Ansicht auf booking_requests. Entscheidungen werden über das Moodle-Bearbeiten-Formular
   *    (Status, Termin, Zeitpunkt) und die native Moodle-Freigabe GESPEICHERT und danach vom Server zurückgelesen.
   * ===================================================================== */
  var SECTIONS = [['new', 'Neue Anfragen'], ['special', 'Spezialanfragen'], ['approved', 'Genehmigte Buchungen'], ['rejected', 'Abgelehnte Buchungen'], ['other', 'Alternativen & Stornierungen'], ['past', 'Vergangene Buchungen']];
  var SLUG = {}; SLUG[CFG.pendingLabel] = 'pending'; SLUG[CFG.approvedLabel] = 'approved'; SLUG[CFG.rejectedLabel] = 'rejected'; SLUG[CFG.altLabel] = 'alt'; SLUG[CFG.cancelledLabel] = 'cancelled';

  function ticketDate(t) { return isConfirmed(t) ? binding(t).date : (t.status === CFG.approvedLabel && t.adate ? t.adate : t.date); }
  function sectionOf(t, today) {
    var d = ticketDate(t);
    if (d && d < today) { return 'past'; }
    if (t.status === CFG.approvedLabel) { return t.approved ? 'approved' : 'new'; }   /* Status ohne Moodle-Freigabe bleibt zur Klärung offen */
    if (t.status === CFG.rejectedLabel) { return 'rejected'; }
    if (t.status === CFG.altLabel || t.status === CFG.cancelledLabel) { return 'other'; }
    return isSpecial(t) ? 'special' : 'new';
  }
  function createdText(t) {
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}:\d{2}))?/.exec(t.created || '');
    return m ? m[3] + '.' + m[2] + '.' + m[1] + (m[4] ? ' ' + m[4] : '') : (t.added || '–');
  }

  /* ----- Speichern über das Moodle-Bearbeiten-Formular ----- */
  function fieldControl(root, name) {
    var w = $('[data-mbs-field="' + name + '"]', root);
    var i = w && w.querySelector('select,textarea,input:not([type=hidden]):not([type=checkbox]):not([type=radio])');
    if (!i) { throw new Error('Feld „' + name + '“ fehlt im Bearbeiten-Formular. Prüfen Sie die Vorlagen.'); }
    return i;
  }
  function setFormField(root, name, value) {
    var i = fieldControl(root, name);
    if (i.tagName === 'SELECT') {
      var ok = false;
      for (var k = 0; k < i.options.length; k++) { if (value !== '' && (i.options[k].text.trim() === value || i.options[k].value === value)) { i.selectedIndex = k; ok = true; break; } }
      if (!ok && value === '') { i.selectedIndex = 0; ok = true; }
      if (!ok) { throw new Error('Die Option „' + value + '“ fehlt im Feld „' + name + '“.'); }
    } else { i.value = value; }
  }
  function getFormField(root, name) {
    var i = fieldControl(root, name);
    if (i.tagName === 'SELECT') { return i.value ? i.options[i.selectedIndex].text.trim() : ''; }
    return String(i.value || '').replace(/\r\n/g, '\n').trim();
  }
  function saveFields(t, changes) {
    var editUrl = t.links.edit;
    if (!editUrl) { return Promise.reject(new Error('Kein Bearbeiten-Link für diese Anfrage (fehlende Moodle-Berechtigung?).')); }
    return fetchDocument(editUrl).then(function (doc) {
      var root = $('#mbs-add', doc), form = root && root.closest('form');
      if (!form) { throw new Error('Das Moodle-Bearbeiten-Formular wurde nicht gefunden.'); }
      Object.keys(changes).forEach(function (k) { setFormField(root, k, changes[k]); });
      var fd = new FormData(form); if (!fd.has('saveandview')) { fd.append('saveandview', 'Save'); }
      var action = new URL(form.getAttribute('action') || editUrl, new URL(editUrl, location.href)).href;
      return fetch(action, { method: 'POST', body: fd, credentials: 'same-origin' });
    }).then(function (r) {
      if (!r.ok || /\/login\//.test(r.url)) { throw new Error('Moodle hat das Speichern abgelehnt (HTTP ' + r.status + ').'); }
      return fetchDocument(editUrl);   /* Rücklesen vom Server */
    }).then(function (doc2) {
      var root2 = $('#mbs-add', doc2); if (!root2) { throw new Error('Kontrolle nach dem Speichern nicht möglich.'); }
      Object.keys(changes).forEach(function (k) {
        var want = String(changes[k]).replace(/\r\n/g, '\n').trim();
        if (getFormField(root2, k) !== want) { throw new Error('Der Server hat „' + k + '“ nicht übernommen. Es wurde nichts als gespeichert gemeldet.'); }
      });
    });
  }
  function nativeStep(t, which) {   /* which: approve | disapprove – echte Moodle-Funktion, per Link mit Sitzungsschlüssel */
    var link = t.links[which];
    if (!link) { return Promise.reject(new Error('Der Moodle-Link zum ' + (which === 'approve' ? 'Freigeben' : 'Freigabe-Entziehen') + ' fehlt (fehlende Berechtigung mod/data:approve?).')); }
    return fetch(link, { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok) { throw new Error('Moodle hat die Freigabe-Aktion abgelehnt (HTTP ' + r.status + ').'); }
      return loadTickets();
    }).then(function (list) {
      var cur = list.filter(function (x) { return String(x.id) === String(t.id); })[0];
      if (!cur || cur.approved !== (which === 'approve')) { throw new Error('Moodle hat die Freigabe nicht geändert.'); }
    });
  }
  function currentOf(list, id) { return list.filter(function (x) { return String(x.id) === String(id); })[0]; }

  /* ----- Termin-Auswahl für Annehmen / Alternativvorschlag ----- */
  function pickerHTML(init) {
    var a = init && init.a, b = init && init.b;
    function opts(sel, key) { return '<option value="">–</option>' + CFG.slots.map(function (s) { return '<option value="' + s.n + '"' + (sel === s.n ? ' selected' : '') + '>Slot ' + s.n + ' · ' + s[key] + (s.special ? ' (Spezial)' : '') + '</option>'; }).join(''); }
    return '<div class="mla-pick"><label>Datum<input type="date" class="mla-pd" value="' + esc(init ? init.date : '') + '"></label>' +
      '<label>Von Slot<select class="mla-ps">' + opts(a, 'start') + '</select></label><label>Bis Slot<select class="mla-pe">' + opts(b, 'end') + '</select></label></div><div class="mla-pcheck" aria-live="polite"></div>';
  }
  function initialPick(t) {
    var w = proposalOf(t) || (t.start && t.end ? wish(t) : null), l = w ? slotsIn(w.start, w.end) : [];
    return { date: w ? w.date : (t.date || ''), a: l.length ? l[0].n : null, b: l.length ? l[l.length - 1].n : null };
  }
  function readPick(dlg) {
    var a = +$('.mla-ps', dlg).value || 0, b = +$('.mla-pe', dlg).value || 0;
    var sa = CFG.slots.filter(function (s) { return s.n === a; })[0], sb = CFG.slots.filter(function (s) { return s.n === b; })[0];
    return { date: normDate($('.mla-pd', dlg).value), a: a, b: b, start: sa ? sa.start : '', end: sb ? sb.end : '' };
  }
  function checkPick(all, t, p) {
    var errs = [], notes = [], today = isoDate(new Date());
    if (!parseDate(p.date)) { errs.push('Bitte ein Datum wählen.'); }
    else if (p.date < today) { errs.push('Das Datum liegt in der Vergangenheit.'); }
    if (!p.start || !p.end) { errs.push('Bitte Start- und Endslot wählen.'); }
    else if (p.b < p.a) { errs.push('Der Endslot liegt vor dem Startslot.'); }
    else if (parseDate(p.date)) {
      var sls = CFG.slots.filter(function (s) { return s.n >= p.a && s.n <= p.b; });
      sls.forEach(function (sl) { var bl = slotBlock(p.date, sl); if (bl) { errs.push('Slot ' + sl.n + ' (' + sl.start + '–' + sl.end + '): ' + bl.reason + '.'); } });
      if (sls.some(function (s) { return s.special; })) { notes.push('Enthält den Spezialslot 13:45–14:30 (nur auf Spezialanfrage).'); }
      conflictsWith(all, { date: p.date, start: p.start, end: p.end }, t.id).forEach(function (x) {
        errs.push('Überschneidung mit der genehmigten Buchung „' + x.group + '“ (' + fmtDate(binding(x).date) + ', ' + timeLabel(binding(x).start, binding(x).end) + ').');
      });
    }
    return { errs: errs, notes: notes };
  }

  /* ----- Dialog ----- */
  function openDialog(o) {
    var wrap = document.createElement('div');
    wrap.className = 'mla-modal'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true'); wrap.setAttribute('aria-labelledby', 'mla-mt');
    wrap.innerHTML = '<div class="mla-md"><h3 id="mla-mt">' + esc(o.title) + '</h3><div class="mla-mb">' + o.body + '</div><div class="mla-me" role="alert" hidden></div>' +
      '<div class="mla-mf"><button type="button" class="mbs-btn mbs-btn-ghost" data-x="cancel">Abbrechen</button><button type="button" class="mbs-btn mla-go is-' + o.tone + '" data-x="ok">' + esc(o.confirm) + '</button></div></div>';
    document.body.appendChild(wrap);
    var ok = $('[data-x=ok]', wrap), cancel = $('[data-x=cancel]', wrap), er = $('.mla-me', wrap), busy = false;
    function close() { document.removeEventListener('keydown', onKey); if (wrap.parentNode) { wrap.parentNode.removeChild(wrap); } }
    function onKey(e) { if (e.key === 'Escape' && !busy) { close(); } }
    document.addEventListener('keydown', onKey);
    cancel.addEventListener('click', function () { if (!busy) { close(); } });
    wrap.addEventListener('click', function (e) { if (e.target === wrap && !busy) { close(); } });
    ok.addEventListener('click', function () {
      if (busy) { return; }
      busy = true; ok.disabled = true; cancel.disabled = true; er.hidden = true; ok.dataset.label = ok.textContent; ok.textContent = 'Speichere …';
      Promise.resolve().then(function () { return o.onConfirm(wrap); }).then(function () { close(); }, function (e) {
        busy = false; ok.disabled = false; cancel.disabled = false; ok.textContent = ok.dataset.label; er.hidden = false; er.textContent = e.message || String(e);
      });
    });
    if (o.onOpen) { o.onOpen(wrap, ok); }
    setTimeout(function () { var f = $('input,select,textarea,button[data-x=ok]', wrap); if (f) { f.focus(); } }, 0);
    return wrap;
  }

  function adminDashboard(root) {
    var bar = $('#mbs-toolbar', root), box = $('#mbs-cards', root);
    var st = { tickets: [], tab: 'new', q: '', date: '' };
    bar.innerHTML = '<div class="mbs-top"><h2>Media Lab · Anfragen</h2><div class="mbs-topbtns"><button type="button" class="mbs-btn mbs-btn-ghost" id="mla-reload">Aktualisieren</button>' +
      '<a class="mbs-btn mbs-btn-ghost" id="mla-monitor" href="#" target="_blank" rel="noopener" style="display:none">Raum-Dashboard öffnen</a></div></div>' +
      '<div class="mla-toast" id="mla-toast" role="status" hidden></div><div class="mla-tabs" id="mla-tabs" role="tablist"></div>' +
      '<div class="mbs-filters"><input type="search" id="mla-q" placeholder="Gruppe, Fach oder Lehrkraft suchen"><input type="date" id="mla-date" aria-label="Datum"><button type="button" class="mbs-btn mbs-btn-ghost" id="mla-reset">Zurücksetzen</button></div>' +
      '<p class="mbs-note" id="mla-info"></p>';
    discover('display').then(function (cm) { var a = $('#mla-monitor'); if (cm && a) { a.href = viewByCm(cm, 'mbs=room'); a.style.display = ''; } });

    function toast(msg, bad) { var t = $('#mla-toast'); t.textContent = msg; t.className = 'mla-toast' + (bad ? ' is-bad' : ''); t.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(function () { t.hidden = true; }, 7000); }
    function reload() {
      return loadTickets().then(function (l) { st.tickets = l; render(); }).catch(function (e) { sourceError(root, e.message); });
    }
    function visible(t) {
      var q = st.q.toLowerCase(), d = st.date;
      var hay = (t.group + ' ' + t.subject + ' ' + t.teacher + ' ' + t.title).toLowerCase();
      return (!q || hay.indexOf(q) > -1) && (!d || ticketDate(t) === d || t.date === d);
    }
    function sortFor(sec, a, b) {
      if (sec === 'approved') { var x = binding(a), y = binding(b); return (x.date + x.start) < (y.date + y.start) ? -1 : 1; }
      if (sec === 'past') { return ticketDate(a) < ticketDate(b) ? 1 : -1; }
      return (+b.id) - (+a.id);
    }
    function flagsHTML(t, all) {
      var f = [], w = wish(t);
      if (isSpecial(t)) { f.push('<li class="is-special">Spezialanfrage: Slot 7 (13:45–14:30) ist nur auf Anfrage buchbar.</li>'); }
      if (t.start && t.end && t.status !== CFG.approvedLabel) {
        slotsIn(w.start, w.end).forEach(function (sl) { var b = slotBlock(w.date, sl); if (b && !f.some(function (x) { return x.indexOf(b.reason) > -1; })) { f.push('<li class="is-warn">Wunschzeit nicht regulär buchbar: ' + esc(b.reason) + '</li>'); } });
        conflictsWith(all, w, t.id).forEach(function (x) { f.push('<li class="is-warn">Überschneidung mit der genehmigten Buchung „' + esc(x.group) + '“.</li>'); });
      }
      if (t.status === CFG.approvedLabel && !t.approved) { f.push('<li class="is-warn">Status „Genehmigt“, aber die Moodle-Freigabe fehlt: Die Buchung gilt nicht als bestätigt.</li>'); }
      if (t.approved && t.status !== CFG.approvedLabel && t.status !== CFG.cancelledLabel) { f.push('<li class="is-warn">In Moodle freigegeben, aber Status „' + esc(t.status) + '“.</li>'); }
      return f.length ? '<ul class="mla-flags">' + f.join('') + '</ul>' : '';
    }
    function cardHTML(t, sec, all) {
      var slug = SLUG[t.status] || 'pending', h = '<article class="mla-card s-' + slug + (isSpecial(t) ? ' is-special' : '') + '" data-id="' + esc(t.id) + '">';
      h += '<header><span class="mla-badge b-' + slug + '">' + esc(t.status) + '</span>' + (isSpecial(t) ? '<span class="mla-badge b-special">Spezialanfrage</span>' : '') + (t.approved ? '<span class="mla-badge b-ok">in Moodle freigegeben</span>' : '') + '<span class="mla-id">Anfrage #' + esc(t.id) + '</span></header>';
      h += '<h3>' + esc(t.group) + '</h3><p class="mla-sub">' + esc(t.subject) + ' · ' + esc(t.teacher) + '</p>';
      h += '<div class="mla-acts">' + t.activities.map(function (a) { return '<span class="mla-chip">' + esc(shortActivity(a)) + '</span>'; }).join('') + '</div>';
      h += '<p class="mla-desc">' + esc(t.desc) + '</p>';
      var w = wish(t), when = (w.start && w.end) ? fmtDate(w.date) + ' · ' + timeLabel(w.start, w.end) : (t.custom ? 'Eigener Vorschlag' + (w.date ? ': ' + fmtDate(w.date) : '') + (t.alttime ? ' (' + t.alttime + ')' : '') : (w.date ? fmtDate(w.date) + ' · Zeit nach Absprache' : '–'));
      h += '<dl class="mla-facts"><div><dt>Wunschtermin</dt><dd>' + esc(when) + '</dd></div><div><dt>Benötigte Zeit</dt><dd>' + esc(t.duration || '–') + '</dd></div><div><dt>Angefragt am</dt><dd>' + esc(createdText(t)) + '</dd></div>';
      if (t.status === CFG.approvedLabel && t.adate) { h += '<div class="is-final"><dt>Vergebener Termin</dt><dd>' + esc(fmtDate(binding(t).date) + ' · ' + timeLabel(binding(t).start, binding(t).end)) + '</dd></div>'; }
      var pr = proposalOf(t); if (pr) { h += '<div class="is-final"><dt>Euer Vorschlag</dt><dd>' + esc(fmtDate(pr.date) + ' · ' + timeLabel(pr.start, pr.end)) + '</dd></div>'; }
      if (t.approvalDate) { h += '<div><dt>Entschieden</dt><dd>' + esc(t.approvalDate + (t.approvedBy ? ' · ' + t.approvedBy : '')) + '</dd></div>'; }
      h += '</dl>';
      if (t.reason) { h += '<p class="mla-reason"><b>Interner Kommentar / Grund:</b> ' + esc(t.reason) + '</p>'; }
      h += flagsHTML(t, all);
      h += '<footer>';
      var open = (sec === 'new' || sec === 'special' || (sec === 'other' && t.status === CFG.altLabel));
      if (open) {
        h += '<button type="button" class="mla-btn mla-yes" data-act="accept" data-id="' + esc(t.id) + '">✓ ANNEHMEN</button><button type="button" class="mla-btn mla-no" data-act="reject" data-id="' + esc(t.id) + '">✕ ABLEHNEN</button>' +
          (t.status !== CFG.altLabel ? '<button type="button" class="mla-btn mla-alt" data-act="alt" data-id="' + esc(t.id) + '">Alternativtermin vorschlagen</button>' : '');
      } else if (sec === 'approved') { h += '<button type="button" class="mla-btn mla-alt" data-act="cancel" data-id="' + esc(t.id) + '">Stornieren</button>'; }
      if (t.links.edit) { h += '<a class="mla-link" href="' + esc(t.links.edit) + '" target="_blank" rel="noopener">In Moodle bearbeiten</a>'; }
      return h + '</footer></article>';
    }
    function render() {
      var today = isoDate(new Date()), all = st.tickets, groups = {};
      SECTIONS.forEach(function (s) { groups[s[0]] = []; });
      all.forEach(function (t) { groups[sectionOf(t, today)].push(t); });
      $('#mla-tabs').innerHTML = SECTIONS.map(function (s) {
        var n = groups[s[0]].length, urgent = (s[0] === 'new' || s[0] === 'special') && n;
        return '<button type="button" role="tab" class="mla-tab' + (st.tab === s[0] ? ' is-on' : '') + (urgent ? ' is-urgent' : '') + (s[0] === 'special' ? ' is-special' : '') + '" data-tab="' + s[0] + '">' + esc(s[1]) + ' <b>' + n + '</b></button>';
      }).join('');
      var list = groups[st.tab].filter(visible).sort(function (a, b) { return sortFor(st.tab, a, b); });
      box.innerHTML = list.map(function (t) { return cardHTML(t, st.tab, all); }).join('');
      var empty = $('#mbs-empty'); if (empty) { empty.hidden = list.length > 0; empty.textContent = 'In diesem Bereich gibt es keine Einträge.'; }
      var info = { new: 'Neue, noch unentschiedene Anfragen. Entscheidungen werden dauerhaft in Moodle gespeichert.', special: 'Anfragen für den Spezialslot 13:45–14:30 (nur auf Spezialanfrage).', approved: 'Bestätigte Buchungen: Moodle-Freigabe und Status „Genehmigt“. Sie erscheinen im Raum-Dashboard.', rejected: 'Abgelehnte Anfragen bleiben dauerhaft erhalten.', other: 'Alternativvorschläge und Stornierungen.', past: 'Vergangene Termine (alle Status), nur zur Ansicht.' }[st.tab];
      $('#mla-info').textContent = info;
    }

    /* ----- Entscheidungen ----- */
    function afterSave(msg) { return reload().then(function () { toast(msg); }); }
    function who() { return currentUserName() || 'Verwaltung'; }
    function openDecision(t, act) {
      if (act === 'reject') {
        openDialog({ title: 'Anfrage ablehnen?', tone: 'no', confirm: '✕ Ja, ablehnen',
          body: '<p>Die Anfrage von <b>' + esc(t.group) + '</b> (' + esc(t.subject) + ') wird abgelehnt. Sie bleibt dauerhaft gespeichert und erscheint rot im Raum-Dashboard (ohne Grund).</p><label class="mla-l">Ablehnungsgrund (optional, intern, wird nicht im Raum-Dashboard angezeigt)<textarea class="mla-reason-in" rows="3"></textarea></label>',
          onConfirm: function (dlg) {
            return loadTickets().then(function (fresh) {
              var cur = currentOf(fresh, t.id); if (!cur) { throw new Error('Die Anfrage wurde nicht mehr gefunden.'); }
              return saveFields(cur, { booking_status: CFG.rejectedLabel, admin_comment: $('.mla-reason-in', dlg).value.trim(), approved_by: who(), approval_date: isoDateTime(new Date()) })
                .then(function () { return cur.approved ? nativeStep(cur, 'disapprove') : null; });
            }).then(function () { return afterSave('Abgelehnt und gespeichert: ' + t.group); });
          } });
        return;
      }
      if (act === 'cancel') {
        openDialog({ title: 'Buchung stornieren?', tone: 'no', confirm: 'Ja, stornieren',
          body: '<p>Die bestätigte Buchung von <b>' + esc(t.group) + '</b> wird storniert und verschwindet aus dem Raum-Dashboard. Der Eintrag bleibt gespeichert.</p><label class="mla-l">Grund (optional, intern)<textarea class="mla-reason-in" rows="2"></textarea></label>',
          onConfirm: function (dlg) {
            return loadTickets().then(function (fresh) {
              var cur = currentOf(fresh, t.id); if (!cur) { throw new Error('Die Buchung wurde nicht mehr gefunden.'); }
              var ch = { booking_status: CFG.cancelledLabel, approved_by: who(), approval_date: isoDateTime(new Date()) }, r = $('.mla-reason-in', dlg).value.trim(); if (r) { ch.admin_comment = r; }
              return saveFields(cur, ch).then(function () { return cur.approved ? nativeStep(cur, 'disapprove') : null; });
            }).then(function () { return afterSave('Storniert und gespeichert: ' + t.group); });
          } });
        return;
      }
      /* accept | alt: Termin wählen, vor dem Speichern gegen die frisch geladenen Serverdaten prüfen */
      var isAccept = act === 'accept';
      openDialog({ title: isAccept ? 'Anfrage annehmen' : 'Alternativtermin vorschlagen', tone: isAccept ? 'yes' : 'alt', confirm: isAccept ? '✓ Verbindlich annehmen' : 'Vorschlag speichern',
        body: '<p><b>' + esc(t.group) + '</b> · ' + esc(t.subject) + ' / ' + esc(t.teacher) + '</p>' + '<p class="mla-hintline">' + (isAccept ? 'Dieser Termin wird verbindlich gespeichert und im Raum-Dashboard angezeigt.' : 'Der Vorschlag ist nicht verbindlich; die Anfrage bekommt den Status „Alternativtermin vorgeschlagen“.') + '</p>' +
          pickerHTML(initialPick(t)) + (isAccept ? '' : '<label class="mla-l">Nachricht an die Gruppe (optional)<textarea class="mla-reason-in" rows="2"></textarea></label>'),
        onOpen: function (dlg, okBtn) {
          function chk() {
            var c = checkPick(st.tickets, t, readPick(dlg)), out = $('.mla-pcheck', dlg);
            out.innerHTML = c.errs.map(function (m) { return '<p class="is-bad">✕ ' + esc(m) + '</p>'; }).join('') + c.notes.map(function (m) { return '<p class="is-note">ℹ ' + esc(m) + '</p>'; }).join('') + (!c.errs.length ? '<p class="is-good">✓ Termin ist frei und regulär buchbar.</p>' : '');
            okBtn.disabled = c.errs.length > 0;
          }
          $$('.mla-pick input,.mla-pick select', dlg).forEach(function (x) { x.addEventListener('input', chk); x.addEventListener('change', chk); }); chk();
        },
        onConfirm: function (dlg) {
          var p = readPick(dlg), note = $('.mla-reason-in', dlg) ? $('.mla-reason-in', dlg).value.trim() : '';
          return loadTickets().then(function (fresh) {   /* frische Serverdaten direkt vor dem Speichern */
            var cur = currentOf(fresh, t.id); if (!cur) { throw new Error('Die Anfrage wurde nicht mehr gefunden.'); }
            var c = checkPick(fresh, cur, p); if (c.errs.length) { throw new Error(c.errs.join(' ')); }
            var ch = { approved_by: who(), approval_date: isoDateTime(new Date()), approved_date: p.date, approved_start: p.start, approved_end: p.end };
            ch.booking_status = isAccept ? CFG.approvedLabel : CFG.altLabel; if (!isAccept && note) { ch.admin_comment = note; }
            return saveFields(cur, ch).then(function () {
              if (isAccept) { return cur.approved ? null : nativeStep(cur, 'approve'); }
              return cur.approved ? nativeStep(cur, 'disapprove') : null;
            });
          }).then(function () { return afterSave((isAccept ? 'Angenommen und gespeichert: ' : 'Alternativvorschlag gespeichert: ') + t.group); });
        } });
    }

    box.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) { return; }
      var t = currentOf(st.tickets, b.dataset.id); if (t) { openDecision(t, b.dataset.act); }
    });
    $('#mla-tabs').addEventListener('click', function (e) { var b = e.target.closest('[data-tab]'); if (b) { st.tab = b.dataset.tab; render(); } });
    $('#mla-q').addEventListener('input', function () { st.q = this.value; render(); });
    $('#mla-date').addEventListener('change', function () { st.date = this.value; render(); });
    $('#mla-reset').addEventListener('click', function () { st.q = ''; st.date = ''; $('#mla-q').value = ''; $('#mla-date').value = ''; render(); });
    $('#mla-reload').addEventListener('click', function () { reload().then(function () { toast('Aktualisiert.'); }); });
    reload();
    setInterval(function () { if (!$('.mla-modal')) { reload(); } }, 60000);
  }

  /* =====================================================================
   * 4) RAUM-DASHBOARD (Vollbild-Monitor): …/mod/data/view.php?id=CMID&mbs=room
   *    Zeigt nur notwendige Angaben: Gruppe, Fach/Lehrkraft, Tätigkeit, Zeit, Status.
   *    Nie: E-Mail, interne Kommentare, Ablehnungsgründe.
   * ===================================================================== */
  var MLR_HTML =
    '<div class="mlr-bg" aria-hidden="true"><i></i><i></i><i></i></div>' +
    '<header class="mlr-top"><div class="mlr-brand"><span class="mlr-logo"></span><b>MEDIA LAB</b><em>Raumbelegung</em></div>' +
    '<div class="mlr-tools"><span class="mlr-conn" id="mlr-conn">Verbinde …</span><button type="button" id="mlr-night" title="Nachtmodus">☾ Nacht</button><button type="button" id="mlr-fs" title="Vollbild">⛶ Vollbild</button></div></header>' +
    '<main class="mlr-grid">' +
    '<section class="mlr-clock" aria-label="Uhr"><div class="mlr-time" id="mlr-time" aria-live="off">' +
    '<span class="mlr-d"></span><span class="mlr-d"></span><span class="mlr-sep">:</span><span class="mlr-d"></span><span class="mlr-d"></span><span class="mlr-sep s">:</span><span class="mlr-d mlr-sec"></span><span class="mlr-d mlr-sec"></span></div>' +
    '<div class="mlr-wd" id="mlr-wd"></div><div class="mlr-date" id="mlr-date"></div>' +
    '<div class="mlr-prog"><div class="mlr-prog-bar"><i id="mlr-prog-fill"></i><u id="mlr-prog-now"></u></div><div class="mlr-prog-l"><span id="mlr-p0"></span><span id="mlr-prog-txt"></span><span id="mlr-p1"></span></div></div></section>' +
    '<section class="mlr-timer" id="mlr-timer" aria-label="Timer"><div class="mlr-h">Timer</div>' +
    '<div class="mlr-ring"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg" id="mlr-ring" cx="60" cy="60" r="52"/></svg><div class="mlr-tval" id="mlr-tval">05:00</div></div>' +
    '<div class="mlr-tset" id="mlr-tset"><label>Min<input type="number" id="mlr-tmin" min="0" max="99" value="5"></label><label>Sek<input type="number" id="mlr-tsec" min="0" max="59" value="0"></label>' +
    '<div class="mlr-presets"><button type="button" data-m="1">1</button><button type="button" data-m="5">5</button><button type="button" data-m="10">10</button><button type="button" data-m="15">15</button><button type="button" data-m="20">20</button></div></div>' +
    '<div class="mlr-tctl"><button type="button" id="mlr-tgo" class="go">Start</button><button type="button" id="mlr-treset">Zurücksetzen</button></div></section>' +
    '<section class="mlr-status" id="mlr-status" aria-live="polite"></section>' +
    '<section class="mlr-board"><div class="mlr-h">Tagesübersicht</div><div class="mlr-bgrid" id="mlr-board"></div>' +
    '<div class="mlr-legend"><span class="k-ok">Genehmigt</span><span class="k-no">Abgelehnt</span><span class="k-pending">Ausstehend (nicht bestätigt)</span><span class="k-special">Spezialanfrage</span><span class="k-blocked">Gesperrt</span></div></section>' +
    '</main><div class="mlr-alarm" id="mlr-alarm" hidden><div><b>ZEIT ABGELAUFEN</b><span>Zum Beenden tippen</span></div></div>';

  function monitor(root) {
    var q = params(), wrap = document.createElement('div'), tickets = [], offline = false, lastOk = null, seen = null, newIds = {}, boardKey = '';
    document.body.classList.add('mbs-room-mode');
    wrap.className = 'mlr'; wrap.innerHTML = MLR_HTML; document.body.appendChild(wrap);
    function $m(s) { return wrap.querySelector(s); }
    var digits = $$('.mlr-d', wrap), TKEY = 'mbs_timer_v3', NKEY = 'mbs_night_v3';
    $m('#mlr-p0').textContent = CFG.dayStart; $m('#mlr-p1').textContent = CFG.dayEnd;

    /* ---------- Nachtmodus & Vollbild ---------- */
    var night = false; try { night = localStorage.getItem(NKEY) === '1'; } catch (e) { /* ignore */ }
    if (q.get('night') === '1') { night = true; }
    function applyNight() { wrap.classList.toggle('is-night', night); $m('#mlr-night').classList.toggle('is-on', night); }
    $m('#mlr-night').addEventListener('click', function () { night = !night; try { localStorage.setItem(NKEY, night ? '1' : '0'); } catch (e) { /* ignore */ } applyNight(); });
    applyNight();
    $m('#mlr-fs').addEventListener('click', function () {
      if (document.fullscreenElement) { document.exitFullscreen(); } else if (document.documentElement.requestFullscreen) { document.documentElement.requestFullscreen(); }
    });

    /* ---------- Digitaluhr: Ziffernwechsel animiert ---------- */
    function setDigit(el, ch) {
      var old = el.getAttribute('data-v');
      if (old === ch) { return; }
      el.setAttribute('data-v', ch);
      if (old === null) { el.textContent = ch; return; }
      el.innerHTML = '<span class="o">' + old + '</span><span class="n">' + ch + '</span>';
    }

    /* ---------- Timer (Zeitstempel-basiert: läuft auch bei gedrosselten Hintergrund-Tabs richtig weiter) ---------- */
    var T = { mode: 'idle', totalMs: 300000, remMs: 300000, endAt: 0 }, ctxAudio = null, alarmUntil = 0, alarmTimer = null;
    try { var saved = JSON.parse(localStorage.getItem(TKEY) || 'null'); if (saved && saved.mode) { T = saved; } } catch (e) { /* ignore */ }
    function saveT() { try { localStorage.setItem(TKEY, JSON.stringify(T)); } catch (e) { /* ignore */ } }
    function remaining() { return T.mode === 'run' ? Math.max(0, T.endAt - Date.now()) : T.remMs; }
    function beep() {
      try {
        if (!ctxAudio) { return; }
        var o = ctxAudio.createOscillator(), g = ctxAudio.createGain(); o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.25;
        o.connect(g); g.connect(ctxAudio.destination); o.start(); o.stop(ctxAudio.currentTime + 0.3);
      } catch (e) { /* ignore */ }
    }
    function startAlarm() {
      $m('#mlr-alarm').hidden = false; wrap.classList.add('is-alarm'); alarmUntil = Date.now() + 30000; beep();
      clearInterval(alarmTimer); alarmTimer = setInterval(function () { if (Date.now() > alarmUntil) { stopAlarm(); } else { beep(); } }, 1200);
    }
    function stopAlarm() { clearInterval(alarmTimer); $m('#mlr-alarm').hidden = true; wrap.classList.remove('is-alarm'); }
    function readSet() { var m = Math.max(0, Math.min(99, +$m('#mlr-tmin').value || 0)), s = Math.max(0, Math.min(59, +$m('#mlr-tsec').value || 0)); return (m * 60 + s) * 1000; }
    function writeSet(ms) { $m('#mlr-tmin').value = Math.floor(ms / 60000); $m('#mlr-tsec').value = Math.floor(ms / 1000) % 60; }
    $m('#mlr-tgo').addEventListener('click', function () {
      try { if (!ctxAudio && (window.AudioContext || window.webkitAudioContext)) { ctxAudio = new (window.AudioContext || window.webkitAudioContext)(); } if (ctxAudio && ctxAudio.resume) { ctxAudio.resume(); } } catch (e) { /* ignore */ }
      if (T.mode === 'run') { T.remMs = remaining(); T.mode = 'pause'; }
      else if (T.mode === 'pause') { T.endAt = Date.now() + T.remMs; T.mode = 'run'; }
      else { var ms = (T.mode === 'done') ? T.totalMs : readSet(); if (ms < 1000) { return; } T.totalMs = ms; T.remMs = ms; T.endAt = Date.now() + ms; T.mode = 'run'; stopAlarm(); }
      saveT(); tick();
    });
    $m('#mlr-treset').addEventListener('click', function () { stopAlarm(); T.mode = 'idle'; T.remMs = T.totalMs; writeSet(T.totalMs); saveT(); tick(); });
    $m('#mlr-alarm').addEventListener('click', stopAlarm);
    $$('.mlr-presets button', wrap).forEach(function (b) { b.addEventListener('click', function () { if (T.mode === 'idle' || T.mode === 'done') { $m('#mlr-tmin').value = b.dataset.m; $m('#mlr-tsec').value = 0; T.mode = 'idle'; T.totalMs = readSet(); T.remMs = T.totalMs; saveT(); tick(); } }); });
    ['#mlr-tmin', '#mlr-tsec'].forEach(function (s) { $m(s).addEventListener('input', function () { if (T.mode === 'idle') { T.totalMs = readSet(); T.remMs = T.totalMs; saveT(); tick(); } }); });
    if (T.mode === 'run' && T.endAt <= Date.now()) { T.mode = 'done'; T.remMs = 0; saveT(); }
    writeSet(T.totalMs);
    function renderTimer() {
      var rem = remaining(), secs = Math.ceil(rem / 1000);
      if (T.mode === 'run' && rem <= 0) { T.mode = 'done'; T.remMs = 0; saveT(); startAlarm(); secs = 0; }
      $m('#mlr-tval').textContent = pad(Math.floor(secs / 60)) + ':' + pad(secs % 60);
      var frac = T.totalMs ? rem / T.totalMs : 0, circ = 2 * Math.PI * 52;
      $m('#mlr-ring').style.strokeDasharray = circ; $m('#mlr-ring').style.strokeDashoffset = circ * (1 - Math.max(0, Math.min(1, frac)));
      var tm = $m('#mlr-timer'), state = T.mode === 'done' ? 'done' : (T.mode === 'run' || T.mode === 'pause') ? (secs <= 10 ? 'crit' : secs <= 60 ? 'warn' : 'ok') : 'idle';
      tm.setAttribute('data-state', state); tm.setAttribute('data-mode', T.mode);
      $m('#mlr-tgo').textContent = T.mode === 'run' ? 'Pause' : T.mode === 'pause' ? 'Fortsetzen' : 'Start';
      $m('#mlr-tset').style.visibility = (T.mode === 'idle' || T.mode === 'done') ? 'visible' : 'hidden';
    }

    /* ---------- Daten ---------- */
    function monKind(t) {
      if (isConfirmed(t)) { return 'ok'; }
      if (t.status === CFG.rejectedLabel) { return CFG.monitor.showRejected ? 'no' : null; }
      if (t.status === CFG.pendingLabel || (t.status === CFG.approvedLabel && !t.approved)) { return CFG.monitor.showPending ? (isSpecial(t) ? 'special' : 'pending') : null; }
      return null;   /* Alternativvorschläge und Stornierungen werden nicht angezeigt */
    }
    function todaysItems(today) {
      var out = [];
      tickets.forEach(function (t) {
        var k = monKind(t); if (!k) { return; }
        var pl = placeOf(t); if (pl.date !== today) { return; }
        var sl = slotsIn(pl.start, pl.end); if (!sl.length) { return; }
        out.push({ t: t, kind: k, a: sl[0].n, b: sl[sl.length - 1].n, start: pl.start, end: pl.end, sl: sl });
      });
      return out.sort(function (x, y) { return x.a - y.a || x.b - y.b; });
    }
    function tagFor(k) { return { ok: 'GENEHMIGT', no: 'ABGELEHNT', pending: 'ANFRAGE · nicht bestätigt', special: 'SPEZIALANFRAGE · nicht bestätigt' }[k]; }

    function renderBoard(now) {
      var today = isoDate(now), wd = now.getDay(), items = todaysItems(today), lanes = [];
      items.forEach(function (it) {
        var l = 0; while (lanes[l] && lanes[l] >= it.a) { l++; }
        lanes[l] = it.b; it.lane = l;
      });
      var L = Math.max(1, lanes.length), h = '';
      CFG.slots.forEach(function (sl) {
        var blk = slotBlock(today, sl);
        h += '<div class="mlr-rowbg" data-n="' + sl.n + '" style="grid-row:' + sl.n + '"></div><div class="mlr-sl" data-n="' + sl.n + '" style="grid-row:' + sl.n + '"><b>' + sl.n + '</b><span>' + sl.start + '–' + sl.end + '</span>' + (sl.special && !blk ? '<em>nur Spezial</em>' : '') + '</div>';
      });
      var i = 0;
      while (i < CFG.slots.length) {
        var b0 = slotBlock(today, CFG.slots[i]);
        if (!b0) { i++; continue; }
        var j = i; while (j + 1 < CFG.slots.length && slotBlock(today, CFG.slots[j + 1]) && slotBlock(today, CFG.slots[j + 1]).reason === b0.reason) { j++; }
        var lim = CFG.limits[wd], main = lim ? (lim.label ? lim.from + '–' + lim.until + ' Uhr – ' + lim.label : lim.note) : b0.reason, sub = (lim && lim.label) ? lim.note : '';
        h += '<div class="mlr-it k-blocked" style="grid-row:' + CFG.slots[i].n + '/' + (CFG.slots[j].n + 1) + ';grid-column:2/-1"><b>' + esc(main) + '</b>' + (sub ? '<span>' + esc(sub) + '</span>' : '') + '</div>';
        i = j + 1;
      }
      items.forEach(function (it) {
        var t = it.t, act = t.activities.length ? t.activities.map(shortActivity).join(' · ') : '';
        h += '<div class="mlr-it k-' + it.kind + (newIds[t.id] ? ' is-new' : '') + '" style="grid-row:' + it.a + '/' + (it.b + 1) + ';grid-column:' + (it.lane + 2) + '"><em>' + esc(tagFor(it.kind)) + '</em><b>' + esc(t.group || t.title) + '</b>' +
          '<span>' + esc([t.subject, t.teacher].filter(Boolean).join(' · ')) + '</span>' + (act ? '<span>' + esc(act) + '</span>' : '') + '<small>' + esc(it.start + '–' + it.end) + '</small></div>';
      });
      var key = h + L; if (key === boardKey) { return; } boardKey = key;
      var g = $m('#mlr-board'); g.style.gridTemplateColumns = '8.5em repeat(' + L + ', minmax(0,1fr))'; g.innerHTML = h;
      newIds = {};
    }
    function markBoard(now) {
      var nm = now.getHours() * 60 + now.getMinutes();
      $$('.mlr-rowbg,.mlr-sl', wrap).forEach(function (el) {
        var sl = CFG.slots[+el.getAttribute('data-n') - 1], s = toMin(sl.start), e = toMin(sl.end);
        el.classList.toggle('is-now', s <= nm && nm < e); el.classList.toggle('is-past', e <= nm);
      });
    }
    function renderStatus(now) {
      var today = isoDate(now), nm = now.getHours() * 60 + now.getMinutes(), ns = nm * 60 + now.getSeconds(), items = todaysItems(today);
      var conf = items.filter(function (x) { return x.kind === 'ok'; });
      var cur = conf.filter(function (x) { return toMin(x.start) <= nm && nm < toMin(x.end); })[0];
      var nxt = conf.filter(function (x) { return toMin(x.start) > nm; }).sort(function (a, b) { return toMin(a.start) - toMin(b.start); })[0];
      var slot = CFG.slots.filter(function (s) { return toMin(s.start) <= nm && nm < toMin(s.end); })[0], first = toMin(CFG.slots[0].start), last = toMin(CFG.slots[CFG.slots.length - 1].end);
      var state, title, sub;
      if (cur) { state = 'busy'; title = 'BELEGT'; sub = esc(cur.t.group) + ' · ' + esc(cur.t.subject) + ' · bis ' + esc(cur.end) + ' Uhr'; }
      else if (slot && slotBlock(today, slot)) { state = 'blocked'; title = 'GESPERRT'; sub = esc(slotBlock(today, slot).reason); }
      else if (slot) { state = 'free'; title = 'FREI'; sub = 'Slot ' + slot.n + ' · ' + slot.start + '–' + slot.end; }
      else if (nm >= first && nm < last) { state = 'break'; title = 'PAUSE'; sub = 'Zwischen zwei Slots'; }
      else { state = 'off'; title = 'GESCHLOSSEN'; sub = 'Außerhalb der Buchungszeiten'; }
      var cd = '';
      if (nxt) { var diff = toMin(nxt.start) * 60 - ns; cd = '<div class="mlr-next"><small>Nächste Buchung · ' + esc(nxt.start) + ' Uhr</small><b>' + esc(nxt.t.group) + '</b><span>' + esc([nxt.t.subject, nxt.t.teacher].filter(Boolean).join(' · ')) + '</span><strong class="mlr-cd">in ' + (diff >= 3600 ? Math.floor(diff / 3600) + ':' : '') + pad(Math.floor(diff % 3600 / 60)) + ':' + pad(diff % 60) + '</strong></div>'; }
      else { cd = '<div class="mlr-next"><small>Nächste Buchung</small><b>Heute keine weitere</b></div>'; }
      var openN = items.filter(function (x) { return x.kind === 'pending' || x.kind === 'special'; }).length;
      var html = '<div class="mlr-now is-' + state + '"><small>Aktuelle Raumbelegung</small><strong>' + title + '</strong><span>' + sub + '</span></div>' + cd +
        (openN ? '<p class="mlr-open">' + openN + ' Anfrage' + (openN > 1 ? 'n' : '') + ' heute noch nicht bestätigt</p>' : '');
      var s = $m('#mlr-status'); if (s.getAttribute('data-h') !== html) { s.setAttribute('data-h', html); s.innerHTML = html; }
    }
    function renderProgress(now) {
      var a = toMin(CFG.dayStart), b = toMin(CFG.dayEnd), nm = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
      var f = Math.max(0, Math.min(1, (nm - a) / (b - a)));
      $m('#mlr-prog-fill').style.width = (f * 100) + '%'; $m('#mlr-prog-now').style.left = (f * 100) + '%';
      $m('#mlr-prog-txt').textContent = (nm < a ? 'Der Tag beginnt um ' + CFG.dayStart : nm >= b ? 'Tag beendet' : 'Tagesfortschritt ' + Math.round(f * 100) + ' %');
    }

    var lastMin = -1;
    function tick() {
      var now = new Date(), s = pad(now.getHours()) + pad(now.getMinutes()) + pad(now.getSeconds());
      digits.forEach(function (el, i) { setDigit(el, s.charAt(i)); });
      $m('#mlr-wd').textContent = now.toLocaleDateString('de-DE', { weekday: 'long' });
      $m('#mlr-date').textContent = now.toLocaleDateString('de-DE', { day: 'numeric', month: 'long', year: 'numeric' });
      renderTimer(); renderStatus(now); renderProgress(now);
      if (now.getMinutes() !== lastMin) { lastMin = now.getMinutes(); renderBoard(now); markBoard(now); }
    }
    function conn() {
      var c = $m('#mlr-conn');
      c.className = 'mlr-conn' + (offline ? ' is-off' : '');
      c.textContent = offline ? 'Keine Verbindung – Stand ' + (lastOk ? pad(lastOk.getHours()) + ':' + pad(lastOk.getMinutes()) : '–') : (lastOk ? 'Aktualisiert ' + pad(lastOk.getHours()) + ':' + pad(lastOk.getMinutes()) + ':' + pad(lastOk.getSeconds()) : 'Verbinde …');
    }
    function refresh() {
      loadTickets().then(function (all) {
        var ids = {}; all.forEach(function (t) { ids[t.id] = 1; });
        if (seen) { all.forEach(function (t) { if (!seen[t.id]) { newIds[t.id] = 1; } }); }
        seen = ids; tickets = all; offline = false; lastOk = new Date(); boardKey = ''; lastMin = -1; tick(); conn();
      }).catch(function () { offline = true; conn(); });
    }
    tick(); conn(); refresh();
    setInterval(tick, 250);
    setInterval(refresh, CFG.refreshSeconds * 1000);
  }

  /* ---------- Start ---------- */
  function isViewPage() { return /\/mod\/data\/view\.php$/.test(location.pathname); }
  function isListMode() { var p = params(); return !p.get('rid') && p.get('mode') !== 'single' && !p.get('advanced') && !p.get('search') && !$('.mbs-single'); }
  /* Moodle gibt die Listen-Vorlage nur aus, wenn es Einträge gibt. Dashboards hängen sich deshalb selbst in die Seite ein. Mit ?mbs=raw abschaltbar. */
  function mountRoot(k) {
    var host = $('[role="main"]') || $('#region-main') || $('main') || document.body, root = document.createElement('div');
    root.className = 'mbs mbs-list-root'; root.setAttribute('data-mbs', 'list'); root.setAttribute('data-kind', k);
    root.innerHTML = '<div class="mbs-toolbar" id="mbs-toolbar"></div><div class="mbs-cards" id="mbs-cards"></div><p class="mbs-empty" id="mbs-empty" hidden></p>';
    var anchor = $('#maincontent', host);
    if (anchor && anchor.parentNode === host) { host.insertBefore(root, anchor.nextSibling); } else { host.insertBefore(root, host.firstChild); }
    document.body.classList.add('mbs-mounted');
    return root;
  }
  function initList() {
    var k = kind(), mode = params().get('mbs');
    if (mode === 'raw') { return; }
    var root = $('.mbs-list-root');
    if (!root && isViewPage() && isListMode()) { root = mountRoot(k); }
    if (!root) { return; }
    if (mode === 'room') { return monitor(root); }
    if (k === 'display') { return planView(root); }
    if (k === 'review') { return adminDashboard(root); }
    return requestsList(root);
  }
  function boot() {
    try { initAdd(); } catch (e) { if (window.console) { console.error('[mbs] add', e); } }
    try { initList(); } catch (e) { if (window.console) { console.error('[mbs] list', e); } }
    try {
      $$('.mbs-single .mbs-comment').forEach(function (c) { if (!$('.mbs-comment-text', c).textContent.trim()) { c.classList.add('is-empty'); } });
    } catch (e) { /* ignorieren */ }
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
}());
